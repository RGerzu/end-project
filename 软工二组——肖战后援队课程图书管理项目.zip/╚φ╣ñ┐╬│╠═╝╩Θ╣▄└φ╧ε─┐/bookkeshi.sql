/*
 Navicat MySQL Data Transfer

 Source Server         : ZJ
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : bookkeshi

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 25/05/2021 20:23:34
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `money` double NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES (3, 'zhangsan', 10000);
INSERT INTO `account` VALUES (4, 'ddd', 10000);
INSERT INTO `account` VALUES (5, 'zsfc', 123);
INSERT INTO `account` VALUES (6, 'daview', 123);

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `book_author` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_quote` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_radio` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `book_web` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`book_name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES ('1984', '[英] 乔治·奥威尔 ', '栗树荫下，我出卖你，你出卖我', '9.3', 'https://fc2tn.baidu.com/it/u=1743897887,1615910928&fm=202');
INSERT INTO `book` VALUES ('一个叫欧维的男人决定去死', '[瑞典] 弗雷德里克·巴克曼 ', '这个发生在瑞典的故事，如生命庆典般绚丽斑斓', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s29071620.jpg');
INSERT INTO `book` VALUES ('一个陌生女人的来信', '[奥] 斯蒂芬·茨威格 ', '暗恋的极致', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s2611329.jpg');
INSERT INTO `book` VALUES ('一千零一夜', '纳训 ', '替天行道', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s1070937.jpg');
INSERT INTO `book` VALUES ('一句顶一万句', '刘震云 ', '一句胜过千年', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s6916838.jpg');
INSERT INTO `book` VALUES ('一桩事先张扬的凶杀案', '[哥伦比亚] 加西亚·马尔克斯 ', '我如此急切地想要讲述这桩案件，也许是它最终确定了我的作家生涯', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s26546959.jpg');
INSERT INTO `book` VALUES ('万历十五年', '[美] 黄仁宇 ', '见微知著，历史观的颠覆', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s1800355.jpg');
INSERT INTO `book` VALUES ('万水千山走遍', '三毛 ', '一个高贵而残破的昨日镜像', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s1099483.jpg');
INSERT INTO `book` VALUES ('万物有灵且美', '[英] 吉米·哈利 ', '活泼的生命完全无须借助魔法，便能对我们述说至美至真的故事', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s4093514.jpg');
INSERT INTO `book` VALUES ('三体全集', '刘慈欣 ', '地球往事三部曲', '9.4', 'https://img9.doubanio.com/view/subject/s/public/s28357056.jpg');
INSERT INTO `book` VALUES ('三国演义（全二册）', '[明] 罗贯中 ', '是非成败转头空', '9.3', 'https://img2.doubanio.com/view/subject/s/public/s1076932.jpg');
INSERT INTO `book` VALUES ('上学记', '何兆武 口述 ', '20世纪中国知识分子的心灵史', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s1950424.jpg');
INSERT INTO `book` VALUES ('上帝掷骰子吗', '曹天元 ', '量子物理史话', '9.2', 'https://img9.doubanio.com/view/subject/s/public/s1486674.jpg');
INSERT INTO `book` VALUES ('不存在的骑士', '[意] 伊塔洛·卡尔维诺 ', '坚持自己的信念，在贫穷中获得欢乐与友谊', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s8972061.jpg');
INSERT INTO `book` VALUES ('世界尽头与冷酷仙境', '[日] 村上春树 ', '人生路上，步履不停，总有那么一点来不及', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s1801057.jpg');
INSERT INTO `book` VALUES ('世界的凛冬', '[英] 肯·福莱特 ', '一个国家只能有一个契约', '8.8', 'https://img1.doubanio.com/view/subject/s/public/s29331058.jpg');
INSERT INTO `book` VALUES ('东方快车谋杀案', '[英] 阿加莎·克里斯蒂 ', '谋杀诡计惊人，波洛的抉择耐人寻味', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s1765799.jpg');
INSERT INTO `book` VALUES ('中国历代政治得失', '钱穆 ', '一部简明的“中国政治制度史”', '9.2', 'https://img9.doubanio.com/view/subject/s/public/s1319205.jpg');
INSERT INTO `book` VALUES ('乡土中国', '费孝通 ', '中国乡土社会传统文化和社会结构理论研究代表作', '9.2', 'https://img3.doubanio.com/view/subject/s/public/s1762210.jpg');
INSERT INTO `book` VALUES ('了不起的盖茨比', '[美] 斯科特·菲茨杰拉德 ', '科学顽童的故事', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s9110246.jpg');
INSERT INTO `book` VALUES ('二手时间', '[白俄] S. A. 阿列克谢耶维奇 ', '你听说过鹦鹉螺号吗？', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s28397415.jpg');
INSERT INTO `book` VALUES ('亮剑', '都梁 ', '面对强大的对手，明知不敌，也要毅然亮剑', '8.9', 'https://img1.doubanio.com/view/subject/s/public/s9950828.jpg');
INSERT INTO `book` VALUES ('亲爱的安德烈', '龙应台 ', '弭平代沟，跨越文化阻隔', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s3993878.jpg');
INSERT INTO `book` VALUES ('人生的智慧', '[德] 阿图尔·叔本华 ', '对世俗、实用问题深刻而透彻的讨论', '9.2', 'https://img9.doubanio.com/view/subject/s/public/s4619775.jpg');
INSERT INTO `book` VALUES ('人生的枷锁', '[英] 毛姆 ', '一切充满了善，然而到处是不凑巧', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s3983958.jpg');
INSERT INTO `book` VALUES ('人类的群星闪耀时', '[奥] 斯蒂芬·茨威格 ', '十四个影响人类文明的瞬间', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s1134166.jpg');
INSERT INTO `book` VALUES ('人类简史', '[以色列] 尤瓦尔·赫拉利 ', '跟着人类一同走过十万年', '9.1', 'https://img2.doubanio.com/view/subject/s/public/s27814883.jpg');
INSERT INTO `book` VALUES ('人间草木', '汪曾祺 ', '我就是要这样香，香得痛痛快快', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s1201610.jpg');
INSERT INTO `book` VALUES ('从一到无穷大', '[美] G. 伽莫夫 ', '科学中的事实和臆测', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s2516920.jpg');
INSERT INTO `book` VALUES ('众病之王', '[美] 悉达多·穆克吉 ', '癌症传', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s24598159.jpg');
INSERT INTO `book` VALUES ('佐贺的超级阿嬷', '[日] 岛田洋七 ', '交叉平行蒙太奇', '8.7', 'https://img2.doubanio.com/view/subject/s/public/s3922462.jpg');
INSERT INTO `book` VALUES ('你一生的故事', '[美] 特德·姜 ', '特德·姜科幻小说集', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s28033064.jpg');
INSERT INTO `book` VALUES ('你好，旧时光（上 下）', '八月长安 ', '原作名切题', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s4293097.jpg');
INSERT INTO `book` VALUES ('你当像鸟飞往你的山', '[美] 塔拉·韦斯特弗 ', '武侠的解构，流氓的狂欢', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s33492346.jpg');
INSERT INTO `book` VALUES ('倚天屠龙记(共四册)', '金庸 ', '不识张郎是张郎', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s1829709.jpg');
INSERT INTO `book` VALUES ('倾城之恋', '张爱玲 ', '“一对平凡的夫妻”之间的“一点真心”', '8.7', 'https://img3.doubanio.com/view/subject/s/public/s4638950.jpg');
INSERT INTO `book` VALUES ('傲慢与偏见', '[英] 奥斯丁 ', '所有现代言情小说的母体', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s4250062.jpg');
INSERT INTO `book` VALUES ('全球通史', '(美) 斯塔夫里阿诺斯 ', '从史前史到21世纪', '9.1', 'https://img2.doubanio.com/view/subject/s/public/s29796663.jpg');
INSERT INTO `book` VALUES ('冬牧场', '李娟 ', '翻手为苍凉，覆手为繁华', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s8958901.jpg');
INSERT INTO `book` VALUES ('冰与火之歌（卷一）', '[美] 乔治·R. R. 马丁 ', '凛冬将至。无比宏大的世界观', '9.3', 'https://img9.doubanio.com/view/subject/s/public/s1358984.jpg');
INSERT INTO `book` VALUES ('刀锋', '[英]毛姆 ', '一把刀的锋刃不容易越过；因此智者说得救之道是困难的', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s2347562.jpg');
INSERT INTO `book` VALUES ('别闹了，费曼先生', '[美] 理查德·费曼 ', '我为它而活着，并为写它推迟了我的死亡', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s1027286.jpg');
INSERT INTO `book` VALUES ('动物农场', '[英] 乔治·奥威尔 ', '太阳底下并无新事', '9.2', 'https://img3.doubanio.com/view/subject/s/public/s2347590.jpg');
INSERT INTO `book` VALUES ('十万个为什么', '少年儿童出版社 ', '完美主义者的最高形态', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s2619779.jpg');
INSERT INTO `book` VALUES ('半生缘', '张爱玲 ', '世钧，我们回不去了', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s2838737.jpg');
INSERT INTO `book` VALUES ('卡拉马佐夫兄弟', '[俄] 费奥多尔·陀思妥耶夫斯基 ', '错综复杂的社会、家庭矛盾和人性悲剧', '9.4', 'https://img3.doubanio.com/view/subject/s/public/s2059791.jpg');
INSERT INTO `book` VALUES ('历史深处的忧虑', '林达 ', '窥见美国社会的一扇窗', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s1768916.jpg');
INSERT INTO `book` VALUES ('厌女', '(日) 上野千鹤子 ', '在各种光怪陆离的场景中，迷失的人性引发了一连串的悲剧', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s27838442.jpg');
INSERT INTO `book` VALUES ('受戒', '汪曾祺 ', '江南乡镇民间生活，健康淳朴的人性', '9.3', 'https://img2.doubanio.com/view/subject/s/public/s3628082.jpg');
INSERT INTO `book` VALUES ('古文观止', '吴楚材 ', '收录自先秦至明末的散文二百二十二篇', '9.1', 'https://img2.doubanio.com/view/subject/s/public/s1325863.jpg');
INSERT INTO `book` VALUES ('叫魂', '[美] 孔飞力 ', '阿勒泰的精灵', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s9015481.jpg');
INSERT INTO `book` VALUES ('台北人', '白先勇 ', '白先勇短篇小说集', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s4526465.jpg');
INSERT INTO `book` VALUES ('史蒂夫·乔布斯传', '[美] 沃尔特·艾萨克森 ', '我们现在怎样做母亲', '8.7', 'https://img2.doubanio.com/view/subject/s/public/s6974202.jpg');
INSERT INTO `book` VALUES ('史记（全十册）', '司马迁 ', '史家之绝唱，无韵之离骚', '9.5', 'https://img9.doubanio.com/view/subject/s/public/s1953384.jpg');
INSERT INTO `book` VALUES ('呐喊', '鲁迅 ', '新文学的第一声呐喊', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s4696893.jpg');
INSERT INTO `book` VALUES ('呼兰河传', '萧红 ', '萧红的童年往事', '8.9', 'https://img3.doubanio.com/view/subject/s/public/s1167060.jpg');
INSERT INTO `book` VALUES ('哈利·波特', 'J.K.罗琳 (J.K.Rowling) ', '从9¾站台开始的旅程', '9.7', 'https://img9.doubanio.com/view/subject/s/public/s29101586.jpg');
INSERT INTO `book` VALUES ('哈姆莱特', '[英] 莎士比亚 ', '生存还是毁灭，这是一个值得思考的问题', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s27009357.jpg');
INSERT INTO `book` VALUES ('哭泣的骆驼', '三毛 ', '沙漠中寻常的生与死', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s1020454.jpg');
INSERT INTO `book` VALUES ('唐诗三百首', '蘅塘退士 ', '熟读唐诗三百首，不会吟诗也会吟', '9.4', 'https://img1.doubanio.com/view/subject/s/public/s1008848.jpg');
INSERT INTO `book` VALUES ('四世同堂', '老舍 ', '谦恭地、勇敢地、真诚地和有纪律地爱他人', '9.3', 'https://img1.doubanio.com/view/subject/s/public/s3228699.jpg');
INSERT INTO `book` VALUES ('围城', '钱锺书 ', '幽默的语言和对生活深刻的观察', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s1070222.jpg');
INSERT INTO `book` VALUES ('國史大綱（上下）', '錢穆 ', '从遥远的撒哈拉到敦煌戈壁', '9.3', 'https://img9.doubanio.com/view/subject/s/public/s23922774.jpg');
INSERT INTO `book` VALUES ('圣经', '中国基督教协会 ', '上帝说，要有光', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s1677577.jpg');
INSERT INTO `book` VALUES ('城南旧事', '林海音 文 ', '长亭外，古道边，芳草碧连天', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s2654869.jpg');
INSERT INTO `book` VALUES ('基督山伯爵', '大仲马 ', '一个报恩复仇的故事，以法国波旁王朝和七月王朝为背景', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s3248016.jpg');
INSERT INTO `book` VALUES ('夏洛的网', '[美] E.B.怀特 ', '中国哲学入门书', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s1120437.jpg');
INSERT INTO `book` VALUES ('多情剑客无情剑(上、中、下)', '古龙 ', '流水滔滔斩不断，情丝百结冲不破', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s1641357.jpg');
INSERT INTO `book` VALUES ('天朝的崩溃', '茅海建 ', '鸦片战争再研究', '9.1', 'https://img2.doubanio.com/view/subject/s/public/s1681072.jpg');
INSERT INTO `book` VALUES ('天龙八部', '金庸 ', '有情皆孽，无人不冤', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s26018275.jpg');
INSERT INTO `book` VALUES ('失明症漫记', '[葡] 若泽·萨拉马戈 ', '失明症迅速蔓延，整个城市陷入一场空前的灾难', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s27217828.jpg');
INSERT INTO `book` VALUES ('失踪的孩子', '[意] 埃莱娜·费兰特 ', '我的整个生命，只是一场为了提升社会地位的低俗斗争。', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s29799269.jpg');
INSERT INTO `book` VALUES ('嫌疑人X的献身', '[日] 东野圭吾 ', '数学好是一种极致的浪漫', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s3254244.jpg');
INSERT INTO `book` VALUES ('孙子兵法', '孙武 ', '我国最古老最杰出的一部兵书', '9.4', 'https://img1.doubanio.com/view/subject/s/public/s2142329.jpg');
INSERT INTO `book` VALUES ('孩子你慢慢来', '龙应台 ', '北平沦陷时代广大平民的悲惨遭遇', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s4124434.jpg');
INSERT INTO `book` VALUES ('孽子', '白先勇 ', '写给那一群， 在最深最深的黑夜里， 独自彷徨街头， 无所依归的孩子们', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s6240330.jpg');
INSERT INTO `book` VALUES ('安娜·卡列尼娜', '[俄] 列夫·托尔斯泰 ', '我亲眼目睹，每一个迈向死亡的生命都在热烈地生长', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s5763939.jpg');
INSERT INTO `book` VALUES ('安徒生童话故事集', '（丹麦）安徒生 ', '为了争取未来的一代', '9.2', 'https://img2.doubanio.com/view/subject/s/public/s1034062.jpg');
INSERT INTO `book` VALUES ('寻路中国', '[美] 彼得·海斯勒 ', '《纽约客》驻北京记者驾车漫游中国大陆的经历', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s32271209.jpg');
INSERT INTO `book` VALUES ('射雕英雄传（全四册）', '金庸 ', '侠之大者，为国为民', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s2157336.jpg');
INSERT INTO `book` VALUES ('小径分岔的花园', '[阿根廷] 豪·路·博尔赫斯 ', '经济学家们的世界观', '8.9', 'https://img1.doubanio.com/view/subject/s/public/s29746559.jpg');
INSERT INTO `book` VALUES ('小王子', '[法] 圣埃克苏佩里 ', '献给长成了大人的孩子们', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s1103152.jpg');
INSERT INTO `book` VALUES ('尼罗河上的惨案', '[英] 阿加莎·克里斯蒂 ', '阿加莎·克里斯蒂代表作', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s1683067.jpg');
INSERT INTO `book` VALUES ('局外人', '[法] 阿尔贝·加缪 ', '人生在世，永远也不该演戏作假', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s4468484.jpg');
INSERT INTO `book` VALUES ('巨人的陨落', '[英] 肯·福莱特 ', '五个家族，一场战争', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s28668834.jpg');
INSERT INTO `book` VALUES ('巨流河', '齐邦媛 ', '两代人从巨流河到哑口海的故事', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s4494379.jpg');
INSERT INTO `book` VALUES ('平凡的世界（全三部）', '路遥 ', '中国当代城乡生活全景', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s1144911.jpg');
INSERT INTO `book` VALUES ('强风吹拂', '三浦紫苑 ', '明明这么痛苦，这么难过，为什么就是不能放弃跑步？', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s27914268.jpg');
INSERT INTO `book` VALUES ('当呼吸化为空气', '[美] 保罗·卡拉尼什 ', '你在死亡中探究生命的意义，你见证生前的呼吸化作死后的空气', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s29423902.jpg');
INSERT INTO `book` VALUES ('影响力', '[美] 罗伯特·西奥迪尼 ', '三毛在加纳利群岛上的生活', '8.6', 'https://img9.doubanio.com/view/subject/s/public/s1657785.jpg');
INSERT INTO `book` VALUES ('彷徨', '鲁迅 ', '路漫漫其修远兮，吾将上下而求索', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s33500305.jpg');
INSERT INTO `book` VALUES ('德米安', '[德] 赫尔曼·黑塞 ', '少年辛克莱寻找通向自身之路的艰辛历程', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s3979854.jpg');
INSERT INTO `book` VALUES ('总统是靠不住的', '林达 ', '美国政治法律制度的基本原理和操作细节', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s2170316.jpg');
INSERT INTO `book` VALUES ('恶意', '[日] 东野圭吾 ', '一个蜘蛛和小猪的故事，写给孩子，也写给大人', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s29069735.jpg');
INSERT INTO `book` VALUES ('悉达多', '[德] 赫尔曼·黑塞 ', '在那最绝望的一刹那，他突然听到了生命之河永恒的声音……', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s6790238.jpg');
INSERT INTO `book` VALUES ('悲惨世界（上中下）', '[法] 雨果 ', '现实主义与浪漫主义的至高杰作', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s4521754.jpg');
INSERT INTO `book` VALUES ('情书', '[日] 岩井俊二 ', '在这本书里，被“审视”的东西杂七杂八', '8.6', 'https://img9.doubanio.com/view/subject/s/public/s1127135.jpg');
INSERT INTO `book` VALUES ('我不知道该说什么，关于死亡还是爱情', 'S.A.阿列克谢耶维奇 ', '真实记录切尔诺贝利核灾难事件', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s28313152.jpg');
INSERT INTO `book` VALUES ('我与地坛', '史铁生 ', '这是你的罪孽与福祉', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s1151479.jpg');
INSERT INTO `book` VALUES ('我们仨', '杨绛 ', '家庭生活回忆录', '8.7', 'https://img2.doubanio.com/view/subject/s/public/s1015872.jpg');
INSERT INTO `book` VALUES ('我的天才女友', '[意] 埃莱娜·费兰特 ', '“那不勒斯四部曲”第一部，两个女人，50年的友谊和战争', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s29164777.jpg');
INSERT INTO `book` VALUES ('我的阿勒泰', '李娟 ', '描写疆北阿勒泰地区生活和风情的原生态散文集', '8.8', 'https://img1.doubanio.com/view/subject/s/public/s6180859.jpg');
INSERT INTO `book` VALUES ('房思琪的初恋乐园', '林奕含 ', '向死而生的文学绝唱', '9.2', 'https://img3.doubanio.com/view/subject/s/public/s29651121.jpg');
INSERT INTO `book` VALUES ('挪威的森林', '[日] 村上春树 ', '像喜欢春天的熊一样', '8.5', 'https://img1.doubanio.com/view/subject/s/public/s27312538.jpg');
INSERT INTO `book` VALUES ('撒哈拉的故事', '三毛 ', '游荡的自由灵魂', '9.2', 'https://img3.doubanio.com/view/subject/s/public/s1066570.jpg');
INSERT INTO `book` VALUES ('故事', '[美] 罗伯特·麦基 ', '材质、结构、风格和银幕剧作的原理', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s27598249.jpg');
INSERT INTO `book` VALUES ('故事新编', '鲁迅 ', '拾取古代传说，取一点因由，随意点染', '9.4', 'https://img9.doubanio.com/view/subject/s/public/s2364685.jpg');
INSERT INTO `book` VALUES ('教父', '[美]马里奥·普佐 ', '“教父三部曲”电影原著', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s2832939.jpg');
INSERT INTO `book` VALUES ('文学回忆录', '木心 口述 ', '木心留给世界的礼物', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s24611679.jpg');
INSERT INTO `book` VALUES ('斯通纳', '[美] 约翰·威廉斯 ', '我来自一个极少有人能想象的家庭，教育给了我新世界', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s28332051.jpg');
INSERT INTO `book` VALUES ('新名字的故事', '[意] 埃莱娜·费兰特 ', '探索青年时代的激情、困惑、挣扎、背叛和失去', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s29376146.jpg');
INSERT INTO `book` VALUES ('无人生还', '[英] 阿加莎・克里斯蒂 ', '童谣杀人案', '8.9', 'https://img3.doubanio.com/view/subject/s/public/s2962510.jpg');
INSERT INTO `book` VALUES ('时间简史', '[英] 史蒂芬·霍金 ', '1768年中国妖术大恐慌', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s1914861.jpg');
INSERT INTO `book` VALUES ('明朝那些事儿（1-9）', '当年明月 ', '不拘一格的历史书写', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s3745215.jpg');
INSERT INTO `book` VALUES ('昨日的世界', '[奥] 斯蒂芬·茨威格 ', '一场同名同姓的误会，两段可贵的爱情', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s1121598.jpg');
INSERT INTO `book` VALUES ('最好的告别', '[美] 阿图·葛文德（Atul Gawande） ', '关于衰老与死亡，你必须知道的常识', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s28355811.jpg');
INSERT INTO `book` VALUES ('最好的我们', '八月长安 ', '耿耿余淮', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s26720726.jpg');
INSERT INTO `book` VALUES ('月亮和六便士', '[英] 毛姆 ', '有多少人会经历顿悟，就有更少的人甘愿自我放逐', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s2659208.jpg');
INSERT INTO `book` VALUES ('朝花夕拾', '鲁迅 ', '在纷扰中寻出一点闲静', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s2875823.jpg');
INSERT INTO `book` VALUES ('杀死一只知更鸟', '[美] 哈珀·李 ', '有一种东西不能遵循从众原则，那就是——人的良心', '9.2', 'https://img2.doubanio.com/view/subject/s/public/s23128183.jpg');
INSERT INTO `book` VALUES ('枪炮、病菌与钢铁', '[美] 贾雷德·戴蒙德 ', '人类社会的命运', '8.7', 'https://img2.doubanio.com/view/subject/s/public/s1738643.jpg');
INSERT INTO `book` VALUES ('树上的男爵', '[意] 伊塔洛·卡尔维诺 ', '是不是真的只有先与人疏离，才能最终与他们在一起？', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s8968135.jpg');
INSERT INTO `book` VALUES ('格林童话全集', '[德国]格林兄弟 ', '一本有教育意义的书', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s1134341.jpg');
INSERT INTO `book` VALUES ('梦里花落知多少', '三毛 ', '探索时间和空间的核心秘密', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s2393243.jpg');
INSERT INTO `book` VALUES ('棋王', '阿城 ', '我从未真正见过火，也未见过毁灭，更不知新生', '8.8', 'https://img1.doubanio.com/view/subject/s/public/s26237958.jpg');
INSERT INTO `book` VALUES ('正见', '宗萨蒋扬钦哲仁波切 ', '佛陀的证悟', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s1993421.jpg');
INSERT INTO `book` VALUES ('此生未完成', '于娟 ', '一个母亲、妻子、女儿的生命日记', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s6343233.jpg');
INSERT INTO `book` VALUES ('步履不停', '[日] 是枝裕和 ', '旧中国老北京贫苦市民的典型命运', '8.7', 'https://img3.doubanio.com/view/subject/s/public/s29425921.jpg');
INSERT INTO `book` VALUES ('毛姆短篇小说精选集', '[英] 威廉·萨默塞特·毛姆 ', '正是悲壮赋予生活以意义', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s24174596.jpg');
INSERT INTO `book` VALUES ('民主的细节', '刘瑜 ', '公民养成手册', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s4146437.jpg');
INSERT INTO `book` VALUES ('水浒传（全二册）', '[明] 施耐庵 ', '三毛少女时代的成长感受', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s1436519.jpg');
INSERT INTO `book` VALUES ('永恒的终结', '[美] 艾萨克·阿西莫夫 ', '关于时间旅行的终极奥秘和恢宏构想', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s29555070.jpg');
INSERT INTO `book` VALUES ('江城', '[美] 彼得·海斯勒 ', '外国人眼中的涪陵', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s32271204.jpg');
INSERT INTO `book` VALUES ('沉默的大多数', '王小波 ', '沉默是沉默者的通行证', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s1447349.jpg');
INSERT INTO `book` VALUES ('活着', '余华 ', '生的苦难与伟大', '9.4', 'https://img3.doubanio.com/view/subject/s/public/s29053580.jpg');
INSERT INTO `book` VALUES ('浪潮之巅', '吴军 ', '了解IT领域的入门读物', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s6807265.jpg');
INSERT INTO `book` VALUES ('浮生六记', '（清）沈复 ', '在法治国家里，民众怎样运用法律', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s2280094.jpg');
INSERT INTO `book` VALUES ('海子的诗', '海子 ', '平淡叙述下的惊心动魄', '8.9', 'https://img3.doubanio.com/view/subject/s/public/s1067491.jpg');
INSERT INTO `book` VALUES ('海底两万里', '[法国] 儒尔·凡尔纳 ', '美国社会心理学的《圣经》', '8.5', 'https://img9.doubanio.com/view/subject/s/public/s1817666.jpg');
INSERT INTO `book` VALUES ('海风中失落的血色馈赠', '[加拿大] 阿利斯泰尔·麦克劳德 ', '男女之间、父母与子女之间紧密的纽带和难以逾越的鸿沟', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s28061231.jpg');
INSERT INTO `book` VALUES ('消失的13级台阶', '[日] 高野和明 ', '一个傻子的土司家族传奇', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s33623978.jpg');
INSERT INTO `book` VALUES ('温柔的夜', '三毛 ', '三毛在加纳利群岛的生活', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s2391798.jpg');
INSERT INTO `book` VALUES ('渴望生活', '[美] 欧文·斯通 ', '梵高悲惨而成就辉煌的人生', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s3099438.jpg');
INSERT INTO `book` VALUES ('激荡三十年', '吴晓波 ', '中国企业1978—2008', '8.6', 'https://img3.doubanio.com/view/subject/s/public/s3203360.jpg');
INSERT INTO `book` VALUES ('火星救援', '[美] 安迪·威尔 ', '跟火星来一场不是你死就是我活的过家家游戏', '8.9', 'https://img1.doubanio.com/view/subject/s/public/s28284337.jpg');
INSERT INTO `book` VALUES ('灿烂千阳', '[美] 卡勒德·胡赛尼 ', '唯有希望与爱可以驱散阴霾', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s2651394.jpg');
INSERT INTO `book` VALUES ('爱你就像爱生命', '王小波 ', '王小波与李银河的两地书', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s4661043.jpg');
INSERT INTO `book` VALUES ('爱的艺术', '[美] 艾·弗洛姆 ', '哲学启蒙书', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s2990934.jpg');
INSERT INTO `book` VALUES ('牡丹亭', '汤显祖 ', '用最为细小的马赛克拼出了一幅完整的后苏联时代图景', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s1075414.jpg');
INSERT INTO `book` VALUES ('牧羊少年奇幻之旅', '[巴西] 保罗·柯艾略 ', '你自己就是最大的宝藏', '8.5', 'https://img1.doubanio.com/view/subject/s/public/s3668327.jpg');
INSERT INTO `book` VALUES ('狂热分子', '[美] 埃里克·霍弗 ', '探讨群众运动的共有特征', '8.9', 'https://img1.doubanio.com/view/subject/s/public/s28036829.jpg');
INSERT INTO `book` VALUES ('献给阿尔吉侬的花束', '[美] 丹尼尔·凯斯 ', '当声称能改造智能的科学实验选中心智障碍主角', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s28050760.jpg');
INSERT INTO `book` VALUES ('王尔德童话', '[英] 王尔德 ', '一颗纯美纯善、永难泯灭的童心', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s2019056.jpg');
INSERT INTO `book` VALUES ('球状闪电', '刘慈欣 ', '量子之外，没有真相', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s26040205.jpg');
INSERT INTO `book` VALUES ('理想国', '[古希腊] 柏拉图 ', '人类历史上最早的乌托邦', '8.8', 'https://img9.doubanio.com/view/subject/s/public/s1068535.jpg');
INSERT INTO `book` VALUES ('白夜行', '[日] 东野圭吾 ', '一宗离奇命案牵出跨度近20年步步惊心的故事', '9.1', 'https://img1.doubanio.com/view/subject/s/public/s24514468.jpg');
INSERT INTO `book` VALUES ('白鹿原', '陈忠实 ', '一轴关于我们民族灵魂的现实主义画卷', '9.2', 'https://img9.doubanio.com/view/subject/s/public/s28111905.jpg');
INSERT INTO `book` VALUES ('百年孤独', '[哥伦比亚] 加西亚·马尔克斯 ', '魔幻现实主义文学代表作', '9.3', 'https://img3.doubanio.com/view/subject/s/public/s27237850.jpg');
INSERT INTO `book` VALUES ('目送', '龙应台 ', '不必追', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s3984108.jpg');
INSERT INTO `book` VALUES ('看不见的城市', '[意大利]伊塔洛·卡尔维诺 ', '哀而不伤', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s1804710.jpg');
INSERT INTO `book` VALUES ('看见', '柴静 ', '在这里看见中国', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s24468373.jpg');
INSERT INTO `book` VALUES ('社会契约论', '卢梭 ', '不到园林，怎知春色如许', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s3470220.jpg');
INSERT INTO `book` VALUES ('社会心理学', '[美] 戴维·迈尔斯 ', '人们是如何思索、影响他人并与他人建立联系的', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s1670932.jpg');
INSERT INTO `book` VALUES ('社会性动物', '埃利奥特·阿伦森Elliot Aronson ', '他是真正的作家，也是真正的农民', '9.1', 'https://img2.doubanio.com/view/subject/s/public/s2783843.jpg');
INSERT INTO `book` VALUES ('神雕侠侣', '金庸 ', '至情至性，情大于武', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s26018916.jpg');
INSERT INTO `book` VALUES ('福尔摩斯探案全集（上中下）', '[英] 阿·柯南道尔 ', '名侦探的代名词', '9.3', 'https://img3.doubanio.com/view/subject/s/public/s1229240.jpg');
INSERT INTO `book` VALUES ('离开的，留下的', '[意] 埃莱娜·费兰特 ', '探索中年的虚无、困惑、野心和近乎残暴的爱', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s29535271.jpg');
INSERT INTO `book` VALUES ('稻草人手记', '三毛 ', '噩梦中的一丝温度', '8.9', 'https://img1.doubanio.com/view/subject/s/public/s3667048.jpg');
INSERT INTO `book` VALUES ('窗边的小豆豆', '[日] 黑柳彻子 著 ', '真正懂孩子的教育经', '8.7', 'https://img3.doubanio.com/view/subject/s/public/s1067911.jpg');
INSERT INTO `book` VALUES ('笑傲江湖（全四册）', '金庸 ', '欲练此功，必先自宫', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s2157335.jpg');
INSERT INTO `book` VALUES ('简爱（英文全本）', '[英] 夏洛蒂·勃朗特 ', '灰姑娘在十九世纪', '8.5', 'https://img9.doubanio.com/view/subject/s/public/s5924326.jpg');
INSERT INTO `book` VALUES ('繁花', '金宇澄 ', '海上繁花，请静观静读', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s26037307.jpg');
INSERT INTO `book` VALUES ('红楼梦', '[清] 曹雪芹 著 ', '都云作者痴，谁解其中味？', '9.6', 'https://img1.doubanio.com/view/subject/s/public/s1070959.jpg');
INSERT INTO `book` VALUES ('经济学原理（上下）', '[美] 曼昆 ', '钱穆中国通史', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s1785715.jpg');
INSERT INTO `book` VALUES ('绿毛水怪', '王小波 ', '我们好象在池塘的水底，从一个月亮走向另一个月亮', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s3675595.jpg');
INSERT INTO `book` VALUES ('罗杰疑案', '[英] 阿加莎·克里斯蒂 ', '以新眼光评旧文学', '9.2', 'https://img2.doubanio.com/view/subject/s/public/s25814002.jpg');
INSERT INTO `book` VALUES ('罗生门', '[日]芥川龙之介 ', '人生，远比地狱更像地狱', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s3435158.jpg');
INSERT INTO `book` VALUES ('罪与罚', '[俄] 陀思妥耶夫斯基 ', '描绘人内心的全部深度', '9.2', 'https://img9.doubanio.com/view/subject/s/public/s1790246.jpg');
INSERT INTO `book` VALUES ('美丽新世界', '[英] 赫胥黎 ', '阿拉伯地区的古代民间传说', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s29477615.jpg');
INSERT INTO `book` VALUES ('美的历程', '李泽厚 ', '中国美学经典之作', '9.2', 'https://img2.doubanio.com/view/subject/s/public/s3893343.jpg');
INSERT INTO `book` VALUES ('老人与海', '海明威 ', '他的犯罪动机是对美的嫉妒', '8.4', 'https://img3.doubanio.com/view/subject/s/public/s1050021.jpg');
INSERT INTO `book` VALUES ('肖申克的救赎', '[美] 斯蒂芬·金 ', '豆瓣电影Top1原著', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s4007145.jpg');
INSERT INTO `book` VALUES ('艺术的故事', '[英] 贡布里希 (Sir E.H.Gombrich) ', '从最早的洞窟绘画到当今的实验艺术', '9.6', 'https://img2.doubanio.com/view/subject/s/public/s3219163.jpg');
INSERT INTO `book` VALUES ('苏菲的世界', '[挪] 乔斯坦·贾德 ', '一个谜语，谜底正是时间', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s3042670.jpg');
INSERT INTO `book` VALUES ('茶馆', '老舍 ', '清末、民初、抗战胜利以后三个历史时期的北京生活风貌', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s33516550.jpg');
INSERT INTO `book` VALUES ('荆棘鸟', '[澳] 考琳·麦卡洛 ', '澳洲乱世情', '8.6', 'https://img9.doubanio.com/view/subject/s/public/s1073574.jpg');
INSERT INTO `book` VALUES ('草房子', '曹文轩 ', '一轴腥风血雨的乱世长卷，中国版《冰与火之歌》', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s2652540.jpg');
INSERT INTO `book` VALUES ('荒原狼', '[德]赫尔曼·黑塞 ', '“超现实主义”风格作品，德国的《尤利西斯》', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s3286369.jpg');
INSERT INTO `book` VALUES ('西游记（全二册）', '吴承恩 ', '神魔皆有人情，精魅亦通世故', '8.9', 'https://img9.doubanio.com/view/subject/s/public/s1627374.jpg');
INSERT INTO `book` VALUES ('解忧杂货店', '[日] 东野圭吾 ', '现代人内心流失的东西，这家杂货店能帮你找回', '8.5', 'https://img3.doubanio.com/view/subject/s/public/s27264181.jpg');
INSERT INTO `book` VALUES ('认识电影', '[美] 路易斯·贾内梯 ', '男孩桑桑刻骨铭心、终身难忘的六年小学生活', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s28274132.jpg');
INSERT INTO `book` VALUES ('许三观卖血记', '余华 ', '以博大的温情描绘磨难中的人生', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s1074291.jpg');
INSERT INTO `book` VALUES ('论语', '中华书局 ', '仁远乎哉？我欲仁，斯仁至矣', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s5804746.jpg');
INSERT INTO `book` VALUES ('设计中的设计', '[日] 原研哉 ', '日常生活的无限可能性', '8.6', 'https://img2.doubanio.com/view/subject/s/public/s2165932.jpg');
INSERT INTO `book` VALUES ('诗经', '孔丘 编订 ', '思无邪', '9.4', 'https://img2.doubanio.com/view/subject/s/public/s1979223.jpg');
INSERT INTO `book` VALUES ('象棋的故事', '[奥] 斯蒂芬·茨威格 ', '纳粹法西斯对人心灵的折磨及摧残', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s2897060.jpg');
INSERT INTO `book` VALUES ('边城', '沈从文 ', '每一座城市都只在想象中耸立，又在描述中坍圮', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s1595557.jpg');
INSERT INTO `book` VALUES ('这些人，那些事', '吴念真 ', '即使不能拥有完美的生活，所幸追求过完整的自我', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s6828981.jpg');
INSERT INTO `book` VALUES ('追风筝的人', '[美] 卡勒德·胡赛尼 ', '为你，千千万万遍', '8.9', 'https://img3.doubanio.com/view/subject/s/public/s1727290.jpg');
INSERT INTO `book` VALUES ('送你一颗子弹', '刘瑜 ', '苟不记之笔墨，未免有辜彼苍之厚', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s4243447.jpg');
INSERT INTO `book` VALUES ('道德经', '黄元吉 ', '中国历史上首部完整的哲学著作', '9.4', 'https://img3.doubanio.com/view/subject/s/public/s1045431.jpg');
INSERT INTO `book` VALUES ('邓小平时代', '[美] 傅高义 ', '个人命运背后的历史变局', '9.2', 'https://img1.doubanio.com/view/subject/s/public/s24516687.jpg');
INSERT INTO `book` VALUES ('野火集', '龙应台 ', '中国人，你为什么不生气', '8.8', 'https://img1.doubanio.com/view/subject/s/public/s1469589.jpg');
INSERT INTO `book` VALUES ('野草', '鲁迅 ', '我以这一丛野草，在明与暗，生与死，过去与未来之际，献于友与仇，人与兽，爱者与不爱者之前作证。', '9.4', 'https://img1.doubanio.com/view/subject/s/public/s2364689.jpg');
INSERT INTO `book` VALUES ('金色梦乡', '[日] 伊坂幸太郎 ', '伊坂幸太郎代表作', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s4444885.jpg');
INSERT INTO `book` VALUES ('金锁记', '张爱玲 ', '一个小商人家庭出身的女子曹七巧的心灵变迁历程', '8.6', 'https://img9.doubanio.com/view/subject/s/public/s2976745.jpg');
INSERT INTO `book` VALUES ('银河帝国：基地七部曲', '[美] 艾萨克·阿西莫夫 ', '营销防骗指南', '9.5', 'https://img9.doubanio.com/view/subject/s/public/s28284246.jpg');
INSERT INTO `book` VALUES ('银河系漫游指南', '[英] 道格拉斯·亚当斯 ', '一场穿越银河的冒险', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s3696740.jpg');
INSERT INTO `book` VALUES ('长日将尽', '[英] 石黑一雄 ', '乐观的外婆却总有神奇的办法', '8.9', 'https://img3.doubanio.com/view/subject/s/public/s29738720.jpg');
INSERT INTO `book` VALUES ('长袜子皮皮', '[瑞典] 阿斯特丽德·林格伦 ', '古典自由主义杰作', '9.0', 'https://img1.doubanio.com/view/subject/s/public/s1290828.jpg');
INSERT INTO `book` VALUES ('阿勒泰的角落', '李娟 ', '白雪和阳光，青草和白桦林', '9.1', 'https://img3.doubanio.com/view/subject/s/public/s6185540.jpg');
INSERT INTO `book` VALUES ('雨季不再来', '三毛 ', '电影入门经典之作', '8.7', 'https://img1.doubanio.com/view/subject/s/public/s2563279.jpg');
INSERT INTO `book` VALUES ('雷雨', '曹禺 ', '一幕人生大悲剧，在一个雷雨夜爆发', '8.6', 'https://img1.doubanio.com/view/subject/s/public/s23579217.jpg');
INSERT INTO `book` VALUES ('霍乱时期的爱情', '[哥伦比亚] 加西亚·马尔克斯 ', '义无反顾地直达爱情的核心', '9.0', 'https://img2.doubanio.com/view/subject/s/public/s11284102.jpg');
INSERT INTO `book` VALUES ('霸王别姬', '李碧华 ', '人间，只是抹去了脂粉的脸', '9.1', 'https://img9.doubanio.com/view/subject/s/public/s24964086.jpg');
INSERT INTO `book` VALUES ('青铜时代', '王小波 ', '唐人传奇贯注现代情趣', '8.7', 'https://img3.doubanio.com/view/subject/s/public/s1072541.jpg');
INSERT INTO `book` VALUES ('面纱', '(英)W.萨默塞特·毛姆 ', '揭去生活的面纱', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s9038826.jpg');
INSERT INTO `book` VALUES ('顾城的诗', '顾城 ', '火焰是我们诗歌唯一的读者', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s1024472.jpg');
INSERT INTO `book` VALUES ('额尔古纳河右岸', '迟子建 ', '东北少数民族鄂温克人生存现状及百年沧桑', '9.0', 'https://img9.doubanio.com/view/subject/s/public/s3380714.jpg');
INSERT INTO `book` VALUES ('飘', '[美国] 玛格丽特·米切尔 ', '革命时期的爱情，随风而逝', '9.3', 'https://img1.doubanio.com/view/subject/s/public/s1078958.jpg');
INSERT INTO `book` VALUES ('飞鸟集', '[印] 罗宾德拉纳德·泰戈尔 ', '一个淡泊清透的世界', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s1044902.jpg');
INSERT INTO `book` VALUES ('香水', '[德] 帕·聚斯金德 ', '阿西莫夫经典科幻小说', '8.8', 'https://img2.doubanio.com/view/subject/s/public/s3867373.jpg');
INSERT INTO `book` VALUES ('鹿鼎记（全五册）', '金庸 ', '在混沌纷扰的生活漩流中，寻求人生的真谛', '8.8', 'https://img3.doubanio.com/view/subject/s/public/s3134040.jpg');
INSERT INTO `book` VALUES ('麦琪的礼物', '[美] 欧·亨利 ', '日常的奇迹', '8.6', 'https://img3.doubanio.com/view/subject/s/public/s1137441.jpg');
INSERT INTO `book` VALUES ('黄金时代', '王小波 ', '我想爱，想吃，还想在一瞬间变成天上半明半暗的云', '8.9', 'https://img2.doubanio.com/view/subject/s/public/s1076372.jpg');
INSERT INTO `book` VALUES ('黑客与画家', '[美] Paul Graham ', '硅谷创业之父Paul Graham文集', '8.7', 'https://img9.doubanio.com/view/subject/s/public/s4669554.jpg');
INSERT INTO `book` VALUES ('鼠疫', '(法)阿尔贝·加缪 ', '用别样的监禁生活再现某种监禁生活，与用不存在的事表现真事同等合理', '9.0', 'https://img3.doubanio.com/view/subject/s/public/s27003191.jpg');

-- ----------------------------
-- Table structure for staff_info
-- ----------------------------
DROP TABLE IF EXISTS `staff_info`;
CREATE TABLE `staff_info`  (
  `staff_id` int(3) NOT NULL AUTO_INCREMENT,
  `staff_number` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工编号',
  `staff_name` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '员工姓名',
  `staff_account` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工账号',
  `staff_pwd` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '密码',
  `staff_phone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '电话',
  PRIMARY KEY (`staff_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '员工信息' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of staff_info
-- ----------------------------
INSERT INTO `staff_info` VALUES (2, 'qwe', 'qwe', 'qwe', '123456', '17707404118');
INSERT INTO `staff_info` VALUES (3, 'zj', 'zhangjie1', 'zhangjie', '123456', '17707404117');

-- ----------------------------
-- Table structure for user_info
-- ----------------------------
DROP TABLE IF EXISTS `user_info`;
CREATE TABLE `user_info`  (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_pwd` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `user_age` int(11) NULL DEFAULT NULL,
  `user_phone` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 201 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user_info
-- ----------------------------
INSERT INTO `user_info` VALUES (200, 'lhw', '123456', 28, '123456789');

SET FOREIGN_KEY_CHECKS = 1;

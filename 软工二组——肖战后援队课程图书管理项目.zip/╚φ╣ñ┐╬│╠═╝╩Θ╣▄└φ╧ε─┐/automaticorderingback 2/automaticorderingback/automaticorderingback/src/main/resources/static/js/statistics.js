// 初始化查询信息
var staffName = "";
var staffPhone = "";
var staffAccount = "";
// 初始化分页参数
var currPage = 1;// 当前页
var totalPage = 1;// 总页数
var offset = 0;// 起始条数
var limit = 5; // 显示条数 5条

var regIllegle = new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]");// 非法字符验证

// 重置按钮添加监听
$("#btnReset").click(function () {
    // 清空内容
    $("#staffAccount").val("");
    $("#staffName").val("");
    $("#staffPhone").val("");
})

// 新增按钮添加监听
$("#btnInsert").click(function () {
    // 清空内容
    $("#insertStaffId").val("");
    $("#insertStaffName").val("");
    $("#insertStaffPhone").val("");
    $("#insertStaffAccount").val("");
    // 窗口显示
    $("#dialogInsert").modal('show', 'fit');
})

// 把信息放入表格中的方法
function addStaffInfoToTable(arr) {
    for (var i = 0; i < arr.length; i++) {
        var num = offset + i + 1;
        var tr = `
		<tr>
			<td>${num}</td>
			<td>${arr[i].staffAccount}</td>
			<td>${arr[i].staffName}</td>
			<td>${arr[i].staffPhone}</td>
			<td>
				<button class="btn btn-link icon icon-times" type="button" staffId="${arr[i].staffId}" onclick="deleteStaffInfo(this)">删除</button>
				<button class="btn btn-link icon icon-edit" type="button" staffId="${arr[i].staffId}" onclick="showUpdateDialog(this)">修改</button>
			</td>		
		</tr>		
		`;
        $("#tbody").append(tr);
    }
}

// 获取信息的方法
function searchStaffInfo() {
    layer.load(2); // 加载样式
    $.ajax({
        url: "searchStaffInfoByPage.do",
        type: "POST",
        dataType: "JSON",
        data: {
            staffAccount: staffAccount,
            staffName:staffName,
            staffPhone:staffPhone,
            limit: limit,
            offset: offset
        },
        success: function (data) {
            layer.closeAll('loading'); // 关闭加载样式
            $("#tbody").html("");// 清空表格
            count = data.datas.count; // 获取记录数量
            // 计算分页
            if (count == 0) {
                // 没有信息就不调用添加方法
                totalPage = 1;
                layer.msg("未查询到相关员工信息！");
            } else {
                totalPage = count % limit == 0 ? (count / limit) : (parseInt(count / limit + 1));
                var staffInfoList = data.datas.staffInfoList; // 获取信息
                addStaffInfoToTable(staffInfoList);
            }
            // 显示页码
            $("#page").html(currPage + "/" + totalPage);
        },
        error: function (err) {
            layer.closeAll('loading'); // 关闭加载样式
        }
    })
}

// 查询按钮添加监听
$("#btnSearch").click(function () {
    // 初始化分页参数
    offset = 0; //记录起始位置
    count = 0; // 记录数
    limit = 5; // 显示条数
    currPage = 1; // 当前页
    totalPage = 1; // 总页数
    // 获取参数
    staffAccount = $("#staffAccount").val();
    staffName = $("#staffName").val();
    staffPhone = $("#staffPhone").val();
    // 调用查询
    searchStaffInfo();
});

// 上一页按钮添加监听
$("#btnPrevPage").click(function () {
    // 判断当前页位置
    if (currPage == 1) {
        layer.msg("已经到首页啦！");
    } else {
        currPage--;
        offset = (currPage - 1) * limit;
        // 调用查询
        searchStaffInfo();
    }
});

// 下一页按钮添加监听
$("#btnNextPage").click(function () {
    // 判断当前页位置
    if (currPage == totalPage) {
        layer.msg("已经到尾页啦！");
    } else {
        currPage++;
        offset = (currPage - 1) * limit;
        // 调用查询
        searchStaffInfo();
    }
});

// 修改窗口弹出的方法
function showUpdateDialog(obj) {
    // 获取当前参数id
    var staffId = obj.getAttribute("staffId");
    layer.load(2); // 加载样式
    // 发送请求
    $.ajax({
        url: "searchStaffInfoById.do",
        type: "POST",
        dataType: "JSON",
        data: {
            staffId: staffId,
            staffName: staffName,
            staffPhone: staffPhone
        },
        success: function (data) {
            layer.closeAll('loading'); // 关闭加载样式
            var staffInfo = data.datas.staffInfo;
            // 修改 修改窗口内容
            $("#updateStaffId").val(staffInfo.staffId);
            $("#updateStaffAccount").val(staffInfo.staffAccount);
            $("#updateStaffName").val(staffInfo.staffName);
            $("#updateStaffPhone").val(staffInfo.staffPhone);
            // 保存按钮添加属性
            $("#btnUpdateSubmit").attr("staffId", staffInfo.staffId);
            $("#btnUpdateSubmit").attr("staffAccount", staffInfo.staffAccount);
            $("#btnUpdateSubmit").attr("staffName", staffInfo.staffName);
            $("#btnUpdateSubmit").attr("staffPhone", staffInfo.staffPhone);
            // 显示窗口
            $("#dialogUpdate").modal('show', 'fit');
        },
        error: function (err) {
            layer.closeAll('loading'); // 关闭加载样式
        }
    })
}

// 新增参数的方法
function insertStaffInfo() {

    // 获取参数
    var staffId = $("#insertStaffId").val();
    var staffAccount = $("#insertStaffAccount").val();
    var staffName = $("#insertStaffName").val();
    var staffPhone = $("#insertStaffPhone").val();
    // 判断参数
    if (staffId.trim() == "" || staffAccount.trim() == "" || staffName.trim() == "" || staffPhone.trim() == "") {
        layer.msg("员工信息填写不完整！");
        return;
    }
    // 验证非法字符
    if (regIllegle.test(staffId) || regIllegle.test(staffAccount) || regIllegle.test(staffName) || regIllegle.test(staffPhone)) {
        layer.msg("含有非法字符！");
        return;
    }

    layer.confirm("您确定要新增该员工信息吗？", {
            btn: ["确定", "取消"],
            icon: 0
        },
        // 确定的方法
        function () {
            layer.load(2); // 加载样式
            // 发送请求
            $.ajax({
                url: "insertStaffInfo.do",
                type: "POST",
                dataType: "JSON",
                data: {
                    staffId: staffId,
                    staffName: staffName,
                    staffAccount: staffAccount,
                    staffPhone: staffPhone
                },
                success: function (data) {
                    layer.closeAll('loading'); // 关闭加载样式
                    if (data.id == 0) {
                        // 操作成功
                        layer.msg(data.msg, {
                            icon: 1,
                            time: 1000
                        });
                        // 窗口关闭
                        $("#dialogInsert").modal('hide', 'fit');
                        // 刷新
                        searchStaffInfo();
                    } else {
                        // 操作失败
                        layer.msg(data.msg, {
                            icon: 2,
                            time: 1000
                        });
                    }
                },
                error: function (err) {
                    layer.closeAll('loading'); // 关闭加载样式
                }
            })
        });

}

// 新增窗口保存按钮添加监听
$("#btnInsertSubmit").click(insertStaffInfo);

// 修改参数的方法
function updateStaffInfo() {
    // 获取参数
    var staffId = $("#updateStaffId").val();
    var staffAccount = $("#updateStaffAccount").val();
    var staffName = $("#updateStaffName").val();
    var staffPhone = $("#updateStaffPhone").val();
    // 判断参数
    if (staffId.trim() == "" || staffAccount.trim() == "" || staffName.trim() == "" || staffPhone.trim() == "") {
        layer.msg("员工信息填写不完整！");
        return;
    }
    // 验证非法字符
    if (regIllegle.test(staffId) || regIllegle.test(staffAccount) || regIllegle.test(staffName) || regIllegle.test(staffPhone)) {
        layer.msg("含有非法字符！");
        return;
    }

    layer.confirm("您确定要修改该员工信息吗？", {
            btn: ["确定", "取消"],
            icon: 0
        },
        // 确定的方法
        function () {
            layer.load(2); // 加载样式
            // 发送请求
            $.ajax({
                url: "updateStaffInfo.do",
                type: "POST",
                dataType: "JSON",
                data: {
                    staffId: staffId,
                    staffAccount: staffAccount,
                    staffName: staffName,
                    staffPhone: staffPhone
                },
                success: function (data) {
                    layer.closeAll('loading'); // 关闭加载样式
                    if (data.id == 0) {
                        // 操作成功
                        layer.msg(data.msg, {
                            icon: 1,
                            time: 1000
                        });
                        // 窗口关闭
                        $("#dialogUpdate").modal('hide', 'fit');
                        // 刷新
                        searchStaffInfo();
                    } else {
                        // 操作失败
                        layer.msg(data.msg, {
                            icon: 2,
                            time: 1000
                        });
                    }
                },
                error: function (err) {
                    layer.closeAll('loading'); // 关闭加载样式
                }
            })
        });

}

// 修改窗口保存按钮添加监听
$("#btnUpdateSubmit").click(updateStaffInfo);

// 删除方法
function deleteStaffInfo(obj) {
    // 获取参数
    var staffId = obj.getAttribute("staffId");
    layer.confirm("是否确认删除该员工信息？", {
            btn: ["确定", "取消"],
            icon: 0
        },
        // 确定的方法
        function () {
            layer.load(2); // 加载样式
            // 发送请求
            $.ajax({
                url: "deleteStaffInfoById.do",
                type: "POST",
                dataType: "JSON",
                data: {
                    staffId: staffId
                },
                success: function (data) {
                    layer.closeAll('loading'); // 关闭加载样式
                    if (data.id == 0) {
                        // 操作成功
                        layer.msg(data.msg, {
                            icon: 1,
                            time: 1000
                        });
                        // 窗口关闭
                        $("#dialogUpdate").modal('hide', 'fit');
                        // 刷新
                        searchStaffInfo();
                    } else {
                        // 操作失败
                        layer.msg(data.msg, {
                            icon: 2,
                            time: 1000
                        });
                    }
                },
                error: function (err) {
                    layer.closeAll('loading'); // 关闭加载样式
                }
            })
        });

}

function selectStaffInfoByNaAndPh(obj) {
    // 获取当前参数name,phone
    var staffName = obj.getAttribute("staffName");
    var staffPhone = obj.getAttribute("staffPhone");
    $.ajax({
        url: "selectStaffInfoByNaAndPh.do",
        type: "POST",
        dataType: "JSON",
        data: {
            staffName: staffName,
            staffPhone: staffPhone
        },
        function() {
        }
    })
}

// 初始化查询
searchStaffInfo();
// 登录的方法
function loginReq() {
	// 获取参数
	var acc = $("#inputAccount").val().trim();
	var pwd = $("#inputPwd").val().trim();
	var veriCode = $("#inputCode").val().trim();
	
	if (acc == "" || pwd == "") {
		layer.msg("请输入账号密码！");
		return;
	}
	if (veriCode == "") {
		layer.msg("请输入验证码");
		return;
	}
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url: "login.do",
		type: "POST",
		dataType: "JSON",
		data: {
			userAccount: acc,
			userPwd: pwd,
			veriCode: veriCode
		},
		success: function(data) {
			layer.closeAll('loading');

			if (data.id == 0) {
				layer.msg(data.msg, {
					icon: 1, //提示的样式
					time: 1000, //1秒关闭（如果不配置，默认是3秒）//设置后不需要自己写定时关闭了，单位是毫秒
					end: function() {
						location.href = "pager.do?p=" + data.location + "&_fmgr" + new Date();
					}
				});
			} else {
				layer.msg(data.msg, {
					icon: 2, //提示的样式
					time: 1000, //1秒关闭（如果不配置，默认是3秒）//设置后不需要自己写定时关闭了，单位是毫秒
				});
				document.getElementById("imgCode").src = "veriCode.do?" + new Date();
			}
		},
		error: function(err) {
			layer.closeAll('loading');
		}
	})
}
// 登录按钮挂监听
$("#btnLogin").click(loginReq);

// 刷新验证码的方法
$("#imgCode").click(function() {
	document.getElementById("imgCode").src = "veriCode.do?" + new Date();
});

/*function test(){
	$.ajax({
		url: "insertOrderInfo.do",
		type: "POST",
		dataType: "JSON",
		data: {

		},
		success: function(data) {
			layer.msg(data.msg, {
				icon: 1, //提示的样式
				time: 1000, //1秒关闭（如果不配置，默认是3秒）//设置后不需要自己写定时关闭了，单位是毫秒
			});
		},
		error: function(err) {
		}

	})
}

test();*/

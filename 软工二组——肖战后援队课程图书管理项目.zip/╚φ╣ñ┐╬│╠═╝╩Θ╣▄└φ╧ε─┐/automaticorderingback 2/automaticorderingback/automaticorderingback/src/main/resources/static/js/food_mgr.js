// 初始化查询信息
var foodName = "";
var typeId = "";
// 初始化分页参数
var currPage = 1;// 当前页
var totalPage = 1;// 总页数
var offset = 0;// 起始条数
var limit = 5; // 显示条数 5条

var regNumber = new RegExp("^[0-9]*$") ;// 数字验证
var regIllegle = new RegExp("[^a-zA-Z0-9\_\u4e00-\u9fa5]");// 非法字符验证

// 新增按钮添加监听
$("#btnInsert").click(function() {
	// 清空内容
	$("#insertFoodName").val("");
	$("#insertTypeSelect option[value='']").prop("selected", true);
	$("#insertFoodPrice").val("");
	// 窗口显示
	$("#dialogInsert").modal('show', 'fit');
})


// 重置按钮添加监听
$("#btnReset").click(function(){
	// 清空内容
	$("#foodName").val("");
	$("#typeSelect option[value='']").prop("selected", true);
})

function getFoodTypeAll(){
	// 开始加载层
	layer.load();
	$.ajax({
		url:'searchFoodTypeByAll.do',
		type:'post',
		dataType:'JSON',
		data:{},
		success:function(msg){
			// 关闭加载层
			layer.closeAll('loading');
			var arr=msg.datas.foodTypeList;
			showFoodTypeList(arr);
		},
		error:function(msg){
			// 关闭加载层
			layer.closeAll('loading');
			// layer的弹框
			layer.alert("请联系管理员！");
		}
	})
}

function showFoodTypeList(arr){
	var str='';
	str+='<option value="">请选择菜品类型</option>';
	for (var i = 0; i < arr.length; i++) {
		str+='<option value="'+arr[i].typeId+'">'+arr[i].typeName+'</option>';
	}
	$('#typeSelect').html(str);
	$('#insertTypeSelect').html(str);
	$('#updateTypeSelect').html(str);
}


// 把信息放入表格中的方法
function addFoodInfoToTable(arr){
	for(var i=0;i<arr.length;i++){
		var num = offset+i+1;
		var tr = `
		<tr>
			<td>${num}</td>
			<td>${arr[i].foodName}</td>
			<td>${arr[i].typeName}</td>
			<td>${arr[i].foodPrice}</td>
			<td>
				<button class="btn btn-link icon icon-times" type="button" foodId="${arr[i].foodId}" onclick="deleteFoodInfo(this)">删除</button>
				<button class="btn btn-link icon icon-edit" type="button" foodId="${arr[i].foodId}" onclick="showUpdateDialog(this)">修改</button>
			</td>		
		</tr>		
		`;
		$("#tbody").append(tr);
		
	}

}

// 获取信息的方法
function searchFoodInfo(){
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url:"searchFoodInfoByPage.do",
		type:"POST",
		dataType:"JSON",
		data:{
			foodName:foodName,
			typeId:typeId,
			limit:limit,
			offset:offset
		},
		success:function(data){
			layer.closeAll('loading'); // 关闭加载样式
			$("#tbody").html("");// 清空表格
			count = data.datas.count; // 获取记录数量
			// 计算分页
			if (count == 0) {
				// 没有信息就不调用添加方法
				totalPage = 1;
				layer.msg("未查询到相关菜品！");
			} else {
				totalPage = count % limit == 0 ? (count / limit) : (parseInt(count / limit + 1));
				var foodInfoList = data.datas.foodInfoRelList; // 获取信息
				addFoodInfoToTable(foodInfoList);
			}
			// 显示页码
			$("#page").html(currPage + "/" + totalPage);
		},
		error:function(err){
			layer.closeAll('loading'); // 关闭加载样式	
		}
	})
		
}

// 查询按钮添加监听
$("#btnSearch").click(function() {
	// 初始化分页参数
	offset = 0; //记录起始位置
	count = 0; // 记录数
	limit = 5; // 显示条数
	currPage = 1; // 当前页
	totalPage = 1; // 总页数
	// 获取参数
	foodName = $("#foodName").val();
	typeId = $("#typeSelect option:selected").val();
	// 调用查询
	searchFoodInfo();
});

// 上一页按钮添加监听
$("#btnPrevPage").click(function() {
	// 判断当前页位置
	if (currPage == 1) {
		layer.msg("已经到首页啦！");
	} else {
		currPage--;
		offset = (currPage - 1) * limit;
		// 调用查询
		searchFoodInfo();
	}
});

// 下一页按钮添加监听
$("#btnNextPage").click(function() {
	// 判断当前页位置
	if (currPage == totalPage) {
		layer.msg("已经到尾页啦！");
	} else {
		currPage++;
		offset = (currPage - 1) * limit;	
		// 调用查询
		searchFoodInfo();
	}
});


// 修改窗口弹出的方法
function showUpdateDialog(obj){
	// 获取当前参数id
	var foodId = obj.getAttribute("foodId");
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url:"searchFoodInfoById.do",
		type:"POST",
		dataType:"JSON",
		data:{
			foodId:foodId
		},
		success:function(data){
			layer.closeAll('loading'); // 关闭加载样式
			var foodInfo = data.datas.foodInfoRel;
			// 修改 修改窗口内容
			$("#updateFoodName").val(foodInfo.foodName);
			$("#updateTypeSelect option[value="+foodInfo.typeId+"]").prop("selected", true);
			$("#updateFoodPrice").val(foodInfo.foodPrice);
			// 保存按钮添加属性
			$("#btnUpdateSubmit").attr("foodId",foodInfo.foodId);
			$("#btnUpdateSubmit").attr("oldFoodTypeId",foodInfo.typeId);
			// 显示窗口
			$("#dialogUpdate").modal('show', 'fit');
		},
		error:function(err){
			layer.closeAll('loading'); // 关闭加载样式	
		}
	})
}


// 新增参数的方法
function insertFoodInfo(){
	
	// 获取参数
	var foodName = $("#insertFoodName").val();
	var typeId =$("#insertTypeSelect option:selected").val();
	var foodPrice = $("#insertFoodPrice").val();
	// 判断参数
	if(foodName.trim()==""||typeId.trim()==""||foodPrice.trim()==""){
		layer.msg("菜品信息填写不完整！");
		return;
	}
	// 验证非法字符
	// if(regIllegle.test(foodName)||regIllegle.test(typeId)||regIllegle.test(foodPrice)){
	// 	layer.msg("含有非法字符！");
	// 	return;
	// }
	// 验证非负整数
	// if(regNumber.test(foodPrice)==false){
	// 	layer.msg("菜品价格，必须大于或等于0的整数！");
	// 	return;
	// }
	layer.confirm("您确定要新增该菜品吗？", {
			btn: ["确定", "取消"],
			icon: 0
		},
		// 确定的方法
		function() {
			layer.load(2); // 加载样式
			// 发送请求
			$.ajax({
				url:"insertFoodInfo.do",
				type:"POST",
				dataType:"JSON",
				data:{
					foodName:foodName,
					typeId:typeId,
					foodPrice:foodPrice
				},
				success:function(data){
					layer.closeAll('loading'); // 关闭加载样式
					if (data.id == 0) {
						// 操作成功						
						layer.msg(data.msg,{
							icon:1,
							time:1000
						});
						// 窗口关闭
						$("#dialogInsert").modal('hide', 'fit');
						// 刷新
						searchFoodInfo();
					} else {
						// 操作失败
						layer.msg(data.msg,{
							icon:2,
							time:1000
						});
					}					
				},
				error:function(err){
					layer.closeAll('loading'); // 关闭加载样式	
				}
			})
		});

}

// 新增窗口保存按钮添加监听
$("#btnInsertSubmit").click(insertFoodInfo);


// 修改参数的方法
function updateFoodInfo(){
	// 获取参数
	var foodId = $("#btnUpdateSubmit").attr("foodId");
	var oldFoodTypeId = $("#btnUpdateSubmit").attr("oldFoodTypeId");
	var foodName = $("#updateFoodName").val();
	var typeId = $("#updateTypeSelect option:selected").val();
	var foodPrice = $("#updateFoodPrice").val();
	// 判断参数
	if(foodName.trim()==""||typeId.trim()==""||foodPrice.trim()==""){
		layer.msg("菜品信息填写不完整！");
		return;
	}
	// 验证非法字符
	// if(regIllegle.test(foodName)||regIllegle.test(typeId)||regIllegle.test(foodPrice)){
	// 	layer.msg("含有非法字符！");
	// 	return;
	// }
	// // 验证非负整数
	// if(regNumber.test(foodPrice)==false){
	// 	layer.msg("菜品价格，必须大于或等于0的整数！");
	// 	return;
	// }
	layer.confirm("您确定要修改该菜品信息吗？", {
			btn: ["确定", "取消"],
			icon: 0
		},
		// 确定的方法
		function() {
			layer.load(2); // 加载样式
			// 发送请求
			$.ajax({
				url:"updateFoodInfo.do",
				type:"POST",
				dataType:"JSON",
				data:{
					foodId:foodId,
					foodName:foodName,
					typeId:typeId,
					foodPrice:foodPrice,
					oldFoodTypeId:oldFoodTypeId
				},
				success:function(data){
					layer.closeAll('loading'); // 关闭加载样式
					if (data.id == 0) {
						// 操作成功						
						layer.msg(data.msg,{
							icon:1,
							time:1000
						});
						// 窗口关闭
						$("#dialogUpdate").modal('hide', 'fit');
						// 刷新
						searchFoodInfo();
					} else {
						// 操作失败
						layer.msg(data.msg,{
							icon:2,
							time:1000
						});
					}					
				},
				error:function(err){
					layer.closeAll('loading'); // 关闭加载样式	
				}
			})
		});
	
}

// 修改窗口保存按钮添加监听
$("#btnUpdateSubmit").click(updateFoodInfo);

// 删除方法
function deleteFoodInfo(obj){
	// 获取参数
	var foodId = obj.getAttribute("foodId");
	layer.confirm("是否确认删除该菜品信息？", {
			btn: ["确定", "取消"],
			icon: 0
		},
		// 确定的方法
		function() {
			layer.load(2); // 加载样式
			// 发送请求
			$.ajax({
				url:"deleteFoodInfoById.do",
				type:"POST",
				dataType:"JSON",
				data:{
					foodId:foodId
				},
				success:function(data){
					layer.closeAll('loading'); // 关闭加载样式
					if (data.id == 0) {
						// 操作成功						
						layer.msg(data.msg,{
							icon:1,
							time:1000
						});
						// 窗口关闭
						$("#dialogUpdate").modal('hide', 'fit');
						// 刷新
						searchFoodInfo();
					} else {
						// 操作失败
						layer.msg(data.msg,{
							icon:2,
							time:1000
						});
					}					
				},
				error:function(err){
					layer.closeAll('loading'); // 关闭加载样式	
				}
			})
		});

}

//初始化获取菜品类型
getFoodTypeAll();

// 初始化查询
searchFoodInfo();
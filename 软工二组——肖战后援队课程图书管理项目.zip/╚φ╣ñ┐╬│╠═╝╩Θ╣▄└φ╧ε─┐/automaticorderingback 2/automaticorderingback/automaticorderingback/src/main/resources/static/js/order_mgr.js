// 初始化查询信息
var orderNumber = "";
var machineUid = "";
var startCtime = '';
var endCtime = '';
// 初始化分页参数
var currPage = 1;// 当前页
var totalPage = 1;// 总页数
var offset = 0;// 起始条数
var limit = 10; // 显示条数 5条
var productType ='';
var product = '';
// 重置按钮添加监听
$("#btnReset").click(function(){
	// 清空内容
	$("#startCtime").val("");
	$("#endCtime").val("");
	$("#orderNumber").val("");
	$("#machineSelect option[value='']").prop("selected", true);
})

//导出监听
$("#daoChu").click(function(){
    offset = 0; //记录起始位置
    limit = 5; // 显示条数
    startCtime = $("#startCtime").val();
    endCtime = $("#endCtime").val();
    orderNumber = $("#orderNumber").val();
    machineUid = $("#machineSelect option:selected").val();
    alert(orderNumber)
    exportAreaExcel();

})

// 导出数据
function exportAreaExcel() {
    // var data ={orderNumber: orderNumber,  machineUid: machineUid,startCtime:startCtime,endCtime:endCtime,	limit:5,
    //     offset:0};


    var oReq = new XMLHttpRequest();
    oReq.open("POST", "export.do", true);
    // xmlhttp.setRequestHeader("Content-Length",arg.lenght);
    oReq.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
    oReq.responseType = "blob";
    oReq.onload = function (oEvent) {
        const link = document.createElement('a')
        var blob = new Blob([oReq.response], {type: 'application/vnd.ms-excel'});
        link.style.display = 'none'
        link.href = URL.createObjectURL(blob);
        let num = ''
        for (var i = 0; i < 10; i++) {
            num += Math.ceil(Math.random() * 10)
        }
        link.setAttribute('download', '用户_' + num + '.xlsx')
        document.body.appendChild(link)
        link.click()
        document.body.removeChild(link)
    };
   // var dto = "{'orderNumber':'王继军','limit':'上海天正','offset':'田林路388号'}";
    // var formData = new FormData();
    // formData.append("data", JSON.stringify({orderNumber:orderNumber,limit:5,offset:0}));
    // //将用户输入值序列化成字符串
    // // alert(JSON.stringify(sendData))
    oReq.send("startCtime="+startCtime+"&endCtime="+endCtime+"&orderNumber="+orderNumber+"&machineUid="+machineUid+"&offset="+offset+"&limit="+limit);
}


function getMachineAll(){
	// 开始加载层
	layer.load();
	$.ajax({
		url:'searchMachineByAll.do',
		type:'post',
		dataType:'JSON',
		data:{},
		success:function(msg){
			// 关闭加载层
			layer.closeAll('loading');
			var arr=msg.datas.machineInfoList;
			showMachineList(arr);
		},
		error:function(msg){
			// 关闭加载层
			layer.closeAll('loading');
			// layer的弹框
			layer.alert("请联系管理员！");
		}
	})
}

function showMachineList(arr){
	var str='';
	str+='<option value="">请选产品类型</option>';
    str+='<option value="'+1+'">'+"蔬菜"+'</option>';
    str+='<option value="'+2+'">'+"水果"+'</option>';

	$('#productType').html(str);
}


// 把信息放入表格中的方法
function addOrderInfoToTable(arr){
	var arrLength = arr.length;
	var money = 0;
	for(var i=0;i<arr.length;i++){
		money=money+parseFloat(arr[i].orderMoney);
		var num = offset+i+1;
		var pay=''
		if(arr[i].productType == 1){
			pay = '蔬菜'
		}else{
			pay = '水果'
		}

		var tr = `
		<tr>
			<td>${num}</td>
			<td>${arr[i].product}</td>
			<td>${pay}</td>
			<td>${arr[i].wholesale}</td>
			<td>${arr[i].minPrice}</td>
			<td>${arr[i].maxPrice}</td>
			<td>${arr[i].avgPrice}</td>
			<td>${arr[i].company}</td>
			<td>${arr[i].dateTime}</td>	
		</tr>		
		`;
		$("#tbody").append(tr);
	}

}

// 获取信息的方法
function searchOrderInfo(){
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url:"searchOrderInfoByPage.do",
		type:"POST",
		dataType:"JSON",
		data:{

            productType:productType,
            product:product,
			limit:limit,
			offset:offset
		},
		success:function(data){
			layer.closeAll('loading'); // 关闭加载样式
			$("#tbody").html("");// 清空表格
			count = data.datas.count; // 获取记录数量
			// 计算分页
			if (count == 0) {
				// 没有信息就不调用添加方法
				totalPage = 1;
				layer.msg("未查询到相关订单信息！");
			} else {
				totalPage = count % limit == 0 ? (count / limit) : (parseInt(count / limit + 1));
				var orderInfoList = data.datas.orderInfoList; // 获取信息
				addOrderInfoToTable(orderInfoList);
			}
			// 显示页码
			$("#page").html(currPage + "/" + totalPage);
		},
		error:function(err){
			layer.closeAll('loading'); // 关闭加载样式	
		}
	})
		
}

// 查询按钮添加监听
$("#btnSearch").click(function() {
	// 初始化分页参数
	offset = 0; //记录起始位置
	count = 0; // 记录数
	limit = 10; // 显示条数
	currPage = 1; // 当前页
	totalPage = 1; // 总页数
	// 获取参数

    productType = $("#productType").val();
    product = $("#product").val();
	// 调用查询
	searchOrderInfo();
});

// 上一页按钮添加监听
$("#btnPrevPage").click(function() {
	// 判断当前页位置
	if (currPage == 1) {
		layer.msg("已经到首页啦！");
	} else {
		currPage--;
		offset = (currPage - 1) * limit;
		// 调用查询
		searchOrderInfo();
	}
});

// 下一页按钮添加监听
$("#btnNextPage").click(function() {
	// 判断当前页位置
	if (currPage == totalPage) {
		layer.msg("已经到尾页啦！");
	} else {
		currPage++;
		offset = (currPage - 1) * limit;	
		// 调用查询
		searchOrderInfo();
	}
});


// 修改窗口弹出的方法
function showDialog(obj){
	// 获取当前参数id
	var orderId = obj.getAttribute("orderId");
	var orderNumber = obj.getAttribute("orderNumber");
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url:"selectDetailByOId.do",
		type:"POST",
		dataType:"JSON",
		data:{
			orderId:orderId,
			orderNumber:orderNumber
		},
		success:function(data){
			layer.closeAll('loading'); // 关闭加载样式
			var orderInfo = data.datas.orderInfo;
			var detailRelList = data.datas.detailRelList;
			
			var ispay='未支付';
			if(orderInfo.orderIspay==1){
				ispay='已支付';
			}
			// 修改 修改窗口内容
			$("#showOrderNumber").html(orderInfo.orderNumber);
			$("#showMachineUid").html(orderInfo.machineUid);
			$("#showDateAndTime").html(orderInfo.orderCtime);
			$("#showOrderMoney").html(orderInfo.orderMoney);
			$("#showOrderIspay").html(ispay);
			$("#showTbody").html("");
			for(var i=0;i<detailRelList.length;i++){
				var num = i+1;
				var tr = `
				<tr>
					<td>${num}</td>
					<td>${detailRelList[i].typeName}</td>
					<td>${detailRelList[i].foodCount}</td>
					<td>${detailRelList[i].foodPrice}</td>	
				</tr>		
				`;
				$("#showTbody").append(tr);
				
			}
			
			// 显示窗口
			$("#dialogShow").modal('show', 'fit');
		},
		error:function(err){
			layer.closeAll('loading'); // 关闭加载样式	
		}
	})
}


//初始化获取收银机
getMachineAll();

// 初始化查询
searchOrderInfo();
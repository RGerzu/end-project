// 注销的请求
function logoutReq() {
	layer.confirm("您确定要注销当前账号吗？", {
			btn: ["确定", "取消"],
			icon: 0
		},
		// 确定的方法
		function() {
			layer.load(2); // 加载样式
			// 发送请求
			$.ajax({
				url: "logout.do",
				type: "GET",
				dataType: "JSON",
				success: function(data) {
					layer.closeAll('loading');
					layer.msg(data.msg, {
						icon: 1, //提示的样式
						time: 1000, //1秒关闭
						end: function() {
							location.href = "pager.do?p=" + data.location + "&_fmgr" + new Date();
						}
					});

				},
				error: function(err) {
					layer.closeAll('loading');
				}
			})
		});

}

//修改密码
function modPwd(){
	$("#oldPwd").val("");
	$("#newPwd").val("");
	$("#againPwd").val("");
	// 窗口开启
	$("#dialogPwd").modal('show', 'fit');
};

//确认修改密码按钮挂监听
$("#confirmPwdBtn").click(function() {
	var oldPwd=$("#oldPwd").val().trim();
	var newPwd=$("#newPwd").val().trim();
	var againPwd=$("#againPwd").val().trim();
	
	if(oldPwd==""){
		layer.msg("请输入旧密码！",{
			icon:2,
			time:1000
		});
		return
	}
	if(newPwd==""){
		layer.msg("请设置新密码！",{
			icon:2,
			time:1000
		});
		return
	}
	if(againPwd==""){
		layer.msg("再次输入密码！",{
			icon:2,
			time:1000
		});
		return
	}
	
	if(newPwd!=againPwd){
		layer.msg("两次新密码输入不一致！",{
			icon:2,
			time:1000
		});
		return
	}
	
	layer.confirm("您确定修改密码？", {
		btn: ["确定", "取消"],
		icon: 0
	},
	// 确定的方法
	function() {
		layer.load(2); // 加载样式
		// 发送请求
		$.ajax({
			url:"updateUserPwdById.do",
			type:"POST",
			dataType:"JSON",
			data:{
				oldPwd:oldPwd,
				newPwd:newPwd,
			},
			success:function(data){
				layer.closeAll('loading'); // 关闭加载样式
				if (data.id == 0) {
					// 窗口关闭
					$("#dialogPwd").modal('hide', 'fit');
					// 操作成功						
					layer.msg(data.msg,{
						icon:1,
						time:1000,
						end: function() {
							location.href = "pager.do?p=" + data.location + "&_fmgr" + new Date();
						}
					});
				} else {
					// 操作失败
					if(data.location!=null&&data.location!=""){
						layer.msg(data.msg,{
							icon:2,
							time:1000,
							end: function() {
								location.href = "pager.do?p=" + data.location + "&_fmgr" + new Date();
							}
						});
					}else{
						layer.msg(data.msg,{
							icon:2,
							time:1000
						});
					}
				}					
			},
			error:function(err){
				layer.closeAll('loading'); // 关闭加载样式	
			}
		})
	});
	
});

//获取个人信息的请求
function getUserInfo() {
	layer.load(2); // 加载样式
	// 发送请求
	$.ajax({
		url: "getUserInfo.do",
		type: "POST",
		dataType: "JSON",
		success: function(data) {
			layer.closeAll('loading');
            if (data.datas.user.type == 2) {
                document.getElementById("food_mgr").style.display="none"
                document.getElementById("machine_mgr").style.display="none"
                document.getElementById("staff_mgr").style.display="none"
            }

			if(data.id==1){
				layer.msg(data.msg,{
					icon:2,
					time:1000,
					end: function() {
						location.href = "pager.do?p=" + data.location + "&_fmgr" + new Date();
					}
				});
				return;
			}

			var user = data.datas.user;
			$("#headerUl").html("");
			showUserInfo(user);
		},
		error: function(err) {
			layer.closeAll('loading');
		}
	})
};

function showUserInfo(user){
	var html = `<li><a href="javascript:void(0);">欢迎您！${user.userName}</a></li>
		<li id="liModPwd"><a href="javascript:void(0);">修改密码</a></li>
		<li id="liLogout"><a href="javascript:void(0);">注销</a></li>`;

	$("#headerUl").append(html);
	
	//修改密码挂监听
	$("#liModPwd").click(modPwd);
	
	//注销挂监听
	$("#liLogout").click(logoutReq);

};


//修改iframe显示url
function changeIframe(obj){
	// 获取url
	var pageUrl = obj.getAttribute("pageUrl");
	// 修改Iframe
	$("#myframe").attr("src",pageUrl+"&_fmgr"+new Date());
}


// 爬取最新按钮监听
$("#btnReset").click(function(){
    layer.load();
    // 清空内容
    $.ajax({
        url: "getPaQu.do",
        type: "POST",
        dataType: "JSON",
        success: function(data) {
            //if ()
            layer.closeAll('loading');
            layer.msg("爬取成功",{
                icon:1,
                time:1000
            });
            return;
        },
        error: function(err) {
            layer.closeAll('loading');
        }
    })
})

//获取个人信息
getUserInfo()

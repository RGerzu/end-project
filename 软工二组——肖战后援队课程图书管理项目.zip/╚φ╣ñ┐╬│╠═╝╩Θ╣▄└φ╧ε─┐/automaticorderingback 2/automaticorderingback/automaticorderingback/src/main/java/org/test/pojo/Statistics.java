package org.test.pojo;

public class Statistics {

    private String typeName;

    private Integer saleCount;

    private Double sunPrice;

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Integer getSaleCount() {
        return saleCount;
    }

    public void setSaleCount(Integer saleCount) {
        this.saleCount = saleCount;
    }

    public Double getSunPrice() {
        return sunPrice;
    }

    public void setSunPrice(Double sunPrice) {
        this.sunPrice = sunPrice;
    }
}

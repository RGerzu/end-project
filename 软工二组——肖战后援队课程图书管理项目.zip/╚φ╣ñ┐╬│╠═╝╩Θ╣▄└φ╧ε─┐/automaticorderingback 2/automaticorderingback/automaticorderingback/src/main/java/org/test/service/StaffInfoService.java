package org.test.service;

import org.apache.ibatis.annotations.Param;
import org.test.dto.SearchStaffInfoDto;
import org.test.pojo.*;

import java.util.List;

public interface StaffInfoService {

    Integer insertStaffInfo(StaffInfo staffInfo);

    Integer updateStaffInfo(StaffInfo staffInfo);

    Integer deleteStaffInfoById(Long staffId);

    List<ProductNew> selectByPage(SearchStaffInfoDto dto);

    Long countStaffInfo(SearchStaffInfoDto dto);

    ProductNew selectStaffInfoById(Long staffId);

    List<StaffInfo> selectByAll();

    StaffInfo selectStaffInfoByUid(String staffNumber);

    StaffInfo selectStaffInfoByNa(String staffAccount);

    StaffInfo selectStaffInfoByPh(String staffPhone);

    StaffInfo selectStaffInfoByUidAndPwd(String staffAccount,String staffPwd);

    StaffInfo selectStaffInfoByNaAndPh(String staffName,String staffPhone);

    List<Statistics> selectStatistics();

    List<StatisticsIsPay> selectOrderIspay();

    List<OrderCount> selectCount();
    
}
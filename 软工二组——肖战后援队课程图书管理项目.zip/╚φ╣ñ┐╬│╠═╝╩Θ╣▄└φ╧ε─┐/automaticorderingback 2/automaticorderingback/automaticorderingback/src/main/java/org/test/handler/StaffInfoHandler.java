package org.test.handler;

import org.test.dto.JsonMessage;
import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.test.dto.SearchStaffInfoDto;
import org.test.pojo.*;
import org.test.service.StaffInfoService;

import java.util.List;

@RestController
public class StaffInfoHandler {
    @Resource
    private StaffInfoService staffInfoService;

    @PostMapping("staffLogin.do")
    public JsonMessage staffLogin(String staffAccount,String staffPwd) {
        System.out.println(staffAccount);
        System.out.println(staffPwd);
        JsonMessage msg = new JsonMessage();
        // 调用业务
        StaffInfo staff = staffInfoService.selectStaffInfoByUidAndPwd(staffAccount, staffPwd);
        if(staff!=null) {
            msg.setId(0);
            msg.setMsg("登录成功！");
            return msg;
        }
        // 回应
        msg.setId(1);
        msg.setMsg("登录失败！");
        return msg;
    }

    @PostMapping("searchStaffInfoByPage.do")
    public JsonMessage searchStaffInfoByPage(SearchStaffInfoDto dto) {
        JsonMessage msg = new JsonMessage();
        // 调用业务
        Long count = staffInfoService.countStaffInfo(dto);
        List<ProductNew> staffInfoList = null;
        if (count > 0) {
            staffInfoList = staffInfoService.selectByPage(dto);
        }
        // 回应
        msg.setId(0);
        msg.getDatas().put("count", count);
        msg.getDatas().put("staffInfoList", staffInfoList);
        return msg;
    }


    @PostMapping("insertStaffInfo.do")
    public JsonMessage insertStaffInfo(StaffInfo staff) {
        JsonMessage msg = new JsonMessage();
        StaffInfo staffInfoA = staffInfoService.selectStaffInfoByUid(staff.getStaffNumber());
        if(staffInfoA!=null) {
            msg.setId(1);
            msg.setMsg("该员工编号已存在！");
            return msg;
        }

        StaffInfo staffInfoB = staffInfoService.selectStaffInfoByNa(staff.getStaffAccount());
        if(staffInfoB!=null) {
            msg.setId(1);
            msg.setMsg("该员账户已存在！");
            return msg;
        }

        StaffInfo staffInfoC = staffInfoService.selectStaffInfoByPh(staff.getStaffPhone());
        if(staffInfoC!=null) {
            msg.setId(1);
            msg.setMsg("该员工手机号已存在！");
            return msg;
        }

        Integer result = staffInfoService.insertStaffInfo(staff);
        // 判断结果
        if (result >0) {
            msg.setId(0);
            msg.setMsg("添加成功！");
        } else{
            msg.setId(1);
            msg.setMsg("添加失败！");
        }
        return msg;
    }

    @PostMapping("updateStaffInfo.do")
    public JsonMessage updateStaffInfo(StaffInfo staffInfo) {
        JsonMessage msg = new JsonMessage();
        Integer result = staffInfoService.updateStaffInfo(staffInfo);
        // 判断结果
        if (result >0) {
            msg.setId(0);
            msg.setMsg("修改成功！");
        } else{
            msg.setId(1);
            msg.setMsg("修改失败！");
        }
        return msg;
    }

    @PostMapping("deleteStaffInfoById.do")
    public JsonMessage deleteStaffInfoById(Long staffId) {
        JsonMessage msg = new JsonMessage();
        Integer result = staffInfoService.deleteStaffInfoById(staffId);
        // 判断结果
        if (result >0) {
            msg.setId(0);
            msg.setMsg("删除成功！");
        } else{
            msg.setId(1);
            msg.setMsg("删除失败！");
        }
        return msg;
    }

    @PostMapping("searchStaffInfoById.do")
    public JsonMessage searchStaffInfoById(Long staffId) {
        JsonMessage msg = new JsonMessage();
        // 调用业务
        ProductNew staffInfo = staffInfoService.selectStaffInfoById(staffId);
        // 判断结果
        msg.setId(0);
        msg.getDatas().put("staffInfo", staffInfo);
        return msg;
    }

    @PostMapping("searchStaffByAll.do")
    public JsonMessage searchStaffByAll() {
        JsonMessage msg = new JsonMessage();
        // 调用业务
        List<StaffInfo> staffInfoList = staffInfoService.selectByAll();
        // 回应
        msg.setId(0);
        msg.getDatas().put("staffInfoList", staffInfoList);
        return msg;
    }

    @PostMapping("selectStaffInfoByNaAndPh.do")
    public JsonMessage selectStaffInfoByNaAndPh(String staffName,String staffPhone) {
        System.out.println(staffName);
        System.out.println(staffPhone);
        JsonMessage msg = new JsonMessage();
        // 调用业务
        StaffInfo staffInfo = staffInfoService.selectStaffInfoByNaAndPh(staffName,staffPhone);
        // 判断结果
        msg.setId(0);
        msg.getDatas().put("staffInfo", staffInfo);
        return msg;
    }


    @PostMapping("statisticsInfoByPage.do")
    public JsonMessage statisticsInfoByPage() {
        JsonMessage msg = new JsonMessage();
        // 调用业务
        List<Statistics> statistics = staffInfoService.selectStatistics();
        List<StatisticsIsPay> statisticsIsPays = staffInfoService.selectOrderIspay();
        List<OrderCount> orderCounts = staffInfoService.selectCount();
        // 回应
        msg.setId(0);
        msg.getDatas().put("statistics", statistics);
        msg.getDatas().put("statisticsIsPays", statisticsIsPays);
        msg.getDatas().put("orderCounts", orderCounts);
        return msg;
    }

}
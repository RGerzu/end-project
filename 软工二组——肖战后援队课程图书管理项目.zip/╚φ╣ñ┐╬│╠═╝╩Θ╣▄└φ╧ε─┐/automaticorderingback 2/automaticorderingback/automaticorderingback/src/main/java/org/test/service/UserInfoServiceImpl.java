package org.test.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.test.mapper.UserInfoMapper;
import org.test.pojo.UserInfo;

@Service 
@Transactional(rollbackFor=Exception.class) // 只要报错就回滚 
public class UserInfoServiceImpl implements UserInfoService{
	@Resource 
	private UserInfoMapper userInfoMapper;

	@Override
	public UserInfo selectByAccAndPwd(String userName, String userPwd) {
		// TODO Auto-generated method stub
		return userInfoMapper.selectByAccAndPwd(userName, userPwd);
	}

    @Override
    public UserInfo selectStaffInfo(String userName, String userPwd) {
        return userInfoMapper.selectStaffInfo(userName,userPwd);
    }

    @Override
	public UserInfo selectUserInfoById(Long userId) {
		// TODO Auto-generated method stub
		return userInfoMapper.selectUserInfoById(userId);
	}

	@Override
	public boolean updateUserPwdById(String newPwd, Long userId) {
		Long result=userInfoMapper.updateUserPwdById(newPwd, userId);
		if(result>0) {
			return true;
		}
		return false;
	}

}

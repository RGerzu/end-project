package org.test;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * 整个项目的启动类
 * @author admin
 */
// @SpringBootApplication 
//  1.自动帮我们扫描当前包之下的所有包里面的java代码,包括当前包
//  2.自动加载我们的配置类（也就是说ssm的配置都在xml里面，那么springboot的配置都以配置类来实现）
@SpringBootApplication
@MapperScan("org.test.mapper")
public class ApplicationBoot extends SpringBootServletInitializer{

	public static void main(String[] args) {
		// 启动SpringBoot项目
		SpringApplication.run(ApplicationBoot.class, args); 
	}
	
//    @Override
//    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
//        return builder.sources(ApplicationBoot.class);
//    }

}

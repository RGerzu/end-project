package org.test.mapper;

import org.apache.ibatis.annotations.Param;
import org.test.pojo.UserInfo;

public interface UserInfoMapper {
 
	UserInfo selectByAccAndPwd(@Param("name")String userName,@Param("pwd")String userPwd);
	UserInfo selectUserInfoById(@Param("userId")Long userId);
	Long updateUserPwdById(@Param("newPwd")String newPwd,@Param("userId")Long userId);

    UserInfo  selectStaffInfo (@Param("name")String userName,@Param("pwd")String userPwd);

}


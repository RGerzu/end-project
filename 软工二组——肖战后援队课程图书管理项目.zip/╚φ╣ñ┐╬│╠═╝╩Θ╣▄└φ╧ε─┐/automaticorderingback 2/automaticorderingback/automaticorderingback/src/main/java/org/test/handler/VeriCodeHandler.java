package org.test.handler;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;


import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.test.util.VeriCodeUtil;

@RestController
public class VeriCodeHandler {

	@GetMapping("veriCode.do")
	public void createVeriCode(HttpSession session, HttpServletResponse resp) throws IOException {
		// 生成验证码
		VeriCodeUtil veriCodeUtil = new VeriCodeUtil();
		String veriCode = veriCodeUtil.createCaptcha(6);
		System.out.println(veriCode);
		// session记录验证码
		session.setAttribute("veriCode", veriCode);
		// 输出图片
		InputStream in = veriCodeUtil.createImage(veriCode);
		OutputStream os = resp.getOutputStream();
		byte[] buffer = new byte[1024];
		int len = -1;
		while ((len = in.read(buffer)) > 0) {
			os.write(buffer, 0, len);
		}
		in.close();
		os.flush();
		os.close();

	}

}

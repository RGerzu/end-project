package org.test.handler;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.test.dto.JsonMessage;

import com.alibaba.fastjson.JSONObject;

@RestController 
public class GetCodeHandler {
	
    @GetMapping("getCode.do")
    public JsonMessage getaccess_tokenurl(String code, HttpServletRequest request) {
    	JsonMessage msg = new JsonMessage();
        String appid ="wx6dfcbb6ad46d83e4";
        String secret="e0c0b8ac0b5189d04c3e6eba9d82fd6d";
        String grant_type="authorization_code";
        
        
        String url = "https://api.weixin.qq.com/sns/jscode2session?" +
                "&appid=" + appid +
                "&secret=" + secret+
                "&js_code="+code+
                "&grant_type="+grant_type;
        RestTemplate rest = new RestTemplate();
         String response = rest.getForObject(url, String.class);
         System.out.println(response);
         
         JSONObject jsonObject = JSONObject.parseObject(response);
         String openid = jsonObject.getString("openid");
         String session_key = jsonObject.getString("session_key");
         
         System.out.println("code:"+code);
         System.out.println("openid:"+openid);
         System.out.println("session_key:"+session_key);
         
         msg.getDatas().put("openid",openid);
         msg.getDatas().put("session_key",session_key);
         
         
         
        return msg;
    }	
	
	
	
	
	
}

package org.test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.test.pojo.Product;
import org.test.pojo.ProductNew;

public interface OrderInfoMapper {

    void insertProduct(@Param("dto") List<Product> dto);

    void insertNews(@Param("dto") List<ProductNew> dto);

    void deleteNew();
    void deletePro();
}


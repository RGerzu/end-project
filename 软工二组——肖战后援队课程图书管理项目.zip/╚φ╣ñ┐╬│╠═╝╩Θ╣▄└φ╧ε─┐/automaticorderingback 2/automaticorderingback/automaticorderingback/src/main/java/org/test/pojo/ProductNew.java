package org.test.pojo;

public class ProductNew {

    private Integer id;
    private String bookName;

    private String bookAuthor;
    private String bookQuote;
    private String bookRadio;
    private String bookWeb;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getBookQuote() {
        return bookQuote;
    }

    public void setBookQuote(String bookQuote) {
        this.bookQuote = bookQuote;
    }

    public String getBookRadio() {
        return bookRadio;
    }

    public void setBookRadio(String bookRadio) {
        this.bookRadio = bookRadio;
    }

    public String getBookWeb() {
        return bookWeb;
    }

    public void setBookWeb(String bookWeb) {
        this.bookWeb = bookWeb;
    }
}

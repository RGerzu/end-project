package org.test.dto;

public class SearchFoodInfoRelDto {
	private String foodName;
	private Long typeId;
	private Integer limit;
	private Integer offset;
	public SearchFoodInfoRelDto() {
		// TODO Auto-generated constructor stub
	}
	public SearchFoodInfoRelDto(String foodName, Long typeId, Integer limit, Integer offset) {
		super();
		this.foodName = foodName;
		this.typeId = typeId;
		this.limit = limit;
		this.offset = offset;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public Long getTypeId() {
		return typeId;
	}
	public void setTypeId(Long typeId) {
		this.typeId = typeId;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public Integer getOffset() {
		return offset;
	}
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	@Override
	public String toString() {
		return "SearchFoodInfoRelDto [foodName=" + foodName + ", typeId=" + typeId + ", limit=" + limit + ", offset="
				+ offset + "]";
	}

}

package org.test.pojo;

public class StatisticsIsPay {

    private Integer isPayName;

    private Integer isPayCount;

    public Integer getIsPayName() {
        return isPayName;
    }

    public void setIsPayName(Integer isPayName) {
        this.isPayName = isPayName;
    }

    public Integer getIsPayCount() {
        return isPayCount;
    }

    public void setIsPayCount(Integer isPayCount) {
        this.isPayCount = isPayCount;
    }
}

package org.test.dto;

import java.util.HashMap;
import java.util.Map;

public class JsonMessage {
	private int id;// 业务操作结果  0为成功 
	private String msg;// 业务操作回应内容
	private String location;// 页面跳转地址 
	private Map<String, Object> datas = new HashMap<String, Object>();// 其他参数
	
	public JsonMessage() {
		// TODO Auto-generated constructor stub
	}

	

	public JsonMessage(int id, String msg, String location, Map<String, Object> datas) {
		super();
		this.id = id;
		this.msg = msg;
		this.location = location;
		this.datas = datas;
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}



	public Map<String, Object> getDatas() {
		return datas;
	}



	public void setDatas(Map<String, Object> datas) {
		this.datas = datas;
	}

	

	
}

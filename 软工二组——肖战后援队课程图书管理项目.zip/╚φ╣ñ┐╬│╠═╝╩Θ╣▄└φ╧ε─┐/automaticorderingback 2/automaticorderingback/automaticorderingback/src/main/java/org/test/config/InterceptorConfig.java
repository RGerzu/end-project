package org.test.config;

import javax.annotation.Resource;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.test.interceptor.XSSInterceptor;

@Configuration
public class InterceptorConfig implements WebMvcConfigurer {
	@Resource
	private XSSInterceptor xssInterceptor;
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(xssInterceptor)
			.addPathPatterns("/*.do");
		WebMvcConfigurer.super.addInterceptors(registry);
	}
}

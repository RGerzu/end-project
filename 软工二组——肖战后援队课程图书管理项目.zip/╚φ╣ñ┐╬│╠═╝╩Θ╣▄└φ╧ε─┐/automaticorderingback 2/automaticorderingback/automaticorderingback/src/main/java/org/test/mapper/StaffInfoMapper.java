package org.test.mapper;

import org.apache.ibatis.annotations.Param;
import org.test.dto.SearchStaffInfoDto;
import org.test.pojo.*;

import java.util.List;

public interface StaffInfoMapper {

    Integer insertStaffInfo(@Param("staff")StaffInfo staffInfo);

    Integer updateStaffInfo(@Param("staff")StaffInfo staffInfo);

    Integer deleteStaffInfoById(@Param("staffId")Long staffId);

    List<ProductNew> selectByPage(@Param("dto")SearchStaffInfoDto dto);

    Long countStaffInfo(@Param("dto")SearchStaffInfoDto dto);

    ProductNew selectStaffInfoById(@Param("staffId")Long staffId);

    StaffInfo selectStaffInfoByUid(@Param("staffNumber") String staffNumber);

    List<StaffInfo> selectByAll();

    StaffInfo selectStaffInfoByNa(@Param("staffAccount")String staffAccount);

    StaffInfo selectStaffInfoByPh(@Param("staffPhone")String staffPhone);

    StaffInfo selectStaffInfoByUidAndPwd(@Param("staffAccount")String staffAccount,@Param("staffPwd")String staffPwd);

    StaffInfo selectStaffInfoByNaAndPh(@Param("staffName")String staffName,@Param("staffPhone")String staffPhone);

    List<Statistics> selectStatistics();

    List<StatisticsIsPay> selectOrderIspay();

    List<OrderCount> selectCount();
}
package org.test.service;

import org.test.pojo.UserInfo;

public interface UserInfoService {
	UserInfo selectByAccAndPwd(String userName,String userPwd);
    UserInfo selectStaffInfo(String userName,String userPwd);
	UserInfo selectUserInfoById(Long userId);
	boolean updateUserPwdById(String newPwd,Long userId);
}

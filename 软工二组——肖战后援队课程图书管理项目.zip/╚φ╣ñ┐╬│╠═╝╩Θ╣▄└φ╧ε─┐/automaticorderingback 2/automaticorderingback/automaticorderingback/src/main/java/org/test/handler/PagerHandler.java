package org.test.handler;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
public class PagerHandler {
	/**
	 * 页面跳转
	 * @param p
	 * @param session
	 * @return
	 */
	@GetMapping("/pager.do")
	public ModelAndView pager(String p,HttpSession session) {
		
		if(p!=null&&p.equals("err404")) {

			return new ModelAndView(p);
		}
		if(p!=null&&p.equals("regist")) {
			return new ModelAndView(p);
		}
		Object obj = session.getAttribute("user");
		if(obj==null) {

			return new ModelAndView("login");
		}
		if(p==null) {
			return new ModelAndView("login");
		}else {
			return new ModelAndView(p);
		}

	}
	
	@GetMapping("/")
	public ModelAndView pager() {
		return new ModelAndView("login");
	}
	
	@RequestMapping("err404")
	public ModelAndView error() {
		return new ModelAndView("err404");
	}
}

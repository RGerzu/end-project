package org.test.pojo;


public class UserInfo{
	private Long userId;  //用户id
	private String userName;  //用户名称
	private String userPwd;  //用户密码
	private String userPhone;  //备注
	private Long userAge;
	private Integer type;
	public UserInfo(){ 

	}
	public UserInfo(Long userId, String userName, String userPwd, String userPhone, Long userAge) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userPhone = userPhone;
		this.userAge = userAge;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public Long getUserAge() {
		return userAge;
	}
	public void setUserAge(Long userAge) {
		this.userAge = userAge;
	}

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}


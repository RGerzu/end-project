package org.test.handler;

import javax.annotation.Resource;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.servlet.http.HttpSession;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.test.dto.JsonMessage;
import org.test.pojo.UserInfo;
import org.test.service.UserInfoService;


import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

@RestController
public class UserInfoHandler {



    private static final Logger LOGGER = LoggerFactory.getLogger(UserInfoHandler.class);
    @Resource
    private UserInfoService userInfoService;


    @PostMapping("login.do")
    public JsonMessage userLogin(String userAccount, String userPwd, String veriCode, HttpSession session) {
        JsonMessage msg = new JsonMessage();
        // 判断验证码是否正确
        veriCode = veriCode.trim();// 去除前后空格
        String realCode = session.getAttribute("veriCode").toString();
        // 不区分大小写判断
        if (veriCode.equalsIgnoreCase(realCode) == false) {
            msg.setId(1);
            msg.setMsg("验证码错误！");
        } else {
            UserInfo user = userInfoService.selectByAccAndPwd(userAccount, userPwd);
            UserInfo userInfo = userInfoService.selectStaffInfo(userAccount, userPwd);
            if (user != null) {
                // 账号密码存在
                user.setType(1);
                session.setAttribute("user", user);
                // 启用状态
                msg.setId(0);
                msg.setMsg("登录成功！欢迎您：" + user.getUserName());
                msg.setLocation("back_main");
            } else {
                if (userInfo != null) {
                    userInfo.setType(2);
                    session.setAttribute("user", userInfo);
                    // 启用状态
                    msg.setId(0);
                    msg.setMsg("登录成功！欢迎您：" + userInfo.getUserName());
                    msg.setLocation("back_main");
                } else {
                    // 账号密码错误 或  用户不存在
                    msg.setId(1);
                    msg.setMsg("账号密码错误！");
                }
            }
        }
        return msg;
    }


    @GetMapping("logout.do")
    public JsonMessage userLogout(HttpSession session) {
        session.invalidate();
        JsonMessage msg = new JsonMessage();
        msg.setId(0);
        msg.setLocation("login");
        msg.setMsg("注销成功！");
        return msg;
    }

    @PostMapping("getUserInfo.do")
    public JsonMessage getUserInfo(HttpSession session) {
        JsonMessage msg = new JsonMessage();
        UserInfo user = (UserInfo) session.getAttribute("user");
        if (user == null) {
            msg.setId(1);
            msg.setMsg("登录过期，请重新登录");
            msg.setLocation("login");
            return msg;
        }
        msg.setId(0);
        msg.getDatas().put("user", user);
        return msg;
    }



    public void test(HttpSession session) {
        String url = "http://192.168.0.16:9006/api/startspider";
        String ip = "192.168.0.16";
        int port = 9006;


        CloseableHttpClient httpclient = HttpClients.custom().setRetryHandler(getHttpRequestRetryHandler()).build();
        HttpGet httpGet = new HttpGet(url);
        Map<String, String> headerMap = new HashMap<>();
        //直接在这个位置设置userAgent
        headerMap.put("User-Agent", "\"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1\"");
        if (headerMap != null) {
            for (String key : headerMap.keySet()) {
                httpGet.setHeader(key, headerMap.get(key));
            }
        }

        httpGet.setConfig(getRequestConfig(ip, port));
        CloseableHttpResponse response = null;
        try {
            response = httpclient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            System.out.println(EntityUtils.toString(entity, "UTF-8").length());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static RequestConfig getRequestConfig(String ip, int port) {
        RequestConfig.Builder builder = RequestConfig.custom()
                .setSocketTimeout(5000)
                .setConnectTimeout(5000)
                .setMaxRedirects(20)
                .setConnectionRequestTimeout(5000);
        if (ip != null && !"".equals(ip)) {
            HttpHost httpHost = new HttpHost(ip, port);
            builder.setProxy(httpHost);
        }
        return builder.build();
    }

    private static HttpRequestRetryHandler getHttpRequestRetryHandler() {
        HttpRequestRetryHandler httpRequestRetryHandler = (exception, executionCount, context) -> {
            if (executionCount > 1) {
                return false;
            }
            if (exception instanceof NoHttpResponseException) {
                return true;
            }
            if (exception instanceof SSLHandshakeException) {
                return false;
            }
            if (exception instanceof InterruptedIOException) {
                return false;
            }
            if (exception instanceof UnknownHostException) {
                return false;
            }
            if (exception instanceof ConnectTimeoutException) {
                return false;
            }
            if (exception instanceof SSLException) {
                return false;
            }

            return false;
        };
        return httpRequestRetryHandler;
    }


    @PostMapping("searchUserInfoById.do")
    public JsonMessage searchUserInfoById(Long userId) {
        JsonMessage msg = new JsonMessage();

        UserInfo userInfo = userInfoService.selectUserInfoById(userId);

        msg.setId(0);
        msg.getDatas().put("userInfo", userInfo);
        return msg;
    }

    @PostMapping("updateUserPwdById.do")
    public JsonMessage updateUserPwdById(String oldPwd, String newPwd, HttpSession session) {
        JsonMessage msg = new JsonMessage();
        UserInfo user = (UserInfo) session.getAttribute("user");
        if (user == null) {
            msg.setId(1);
            msg.setMsg("登录过期，请重新登录");
            msg.setLocation("login");
            return msg;
        }
        if (user.getUserPwd().equals(oldPwd)) {
            boolean result = userInfoService.updateUserPwdById(newPwd, user.getUserId());
            if (result) {
                msg.setId(0);
                msg.setMsg("密码修改成功！请重新登录！");
                msg.setLocation("login");
                return msg;
            }
        } else {
            msg.setId(1);
            msg.setMsg("原密码输入错误！");
            return msg;
        }

        msg.setId(1);
        msg.setMsg("密码修改失败！");
        return msg;
    }
}


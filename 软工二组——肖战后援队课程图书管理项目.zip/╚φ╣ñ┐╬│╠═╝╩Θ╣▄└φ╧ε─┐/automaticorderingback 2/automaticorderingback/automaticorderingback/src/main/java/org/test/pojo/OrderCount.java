package org.test.pojo;

public class OrderCount {

    private String orderCtime;

    private Double orderMoney;

    public String getOrderCtime() {
        return orderCtime;
    }

    public void setOrderCtime(String orderCtime) {
        this.orderCtime = orderCtime;
    }

    public Double getOrderMoney() {
        return orderMoney;
    }

    public void setOrderMoney(Double orderMoney) {
        this.orderMoney = orderMoney;
    }
}

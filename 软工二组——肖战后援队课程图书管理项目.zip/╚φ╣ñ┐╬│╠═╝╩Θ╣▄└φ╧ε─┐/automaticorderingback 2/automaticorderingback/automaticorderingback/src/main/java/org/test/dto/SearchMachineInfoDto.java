package org.test.dto;

public class SearchMachineInfoDto {
	private String machineUid;
	private Integer limit;
	private Integer offset;
	public SearchMachineInfoDto() {
		// TODO Auto-generated constructor stub
	}
	public SearchMachineInfoDto(String machineUid, Integer limit, Integer offset) {
		super();
		this.machineUid = machineUid;
		this.limit = limit;
		this.offset = offset;
	}
	public String getMachineUid() {
		return machineUid;
	}
	public void setMachineUid(String machineUid) {
		this.machineUid = machineUid;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	public Integer getOffset() {
		return offset;
	}
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	
}

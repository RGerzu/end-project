package org.test.util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import javax.imageio.ImageIO;


public class VeriCodeUtil {

	/**
	 * 生成验证码的方法
	 * 
	 * @param length 验证码长度
	 * @return 验证码字符串
	 */
	public String createCaptcha(int length) {
		char[] codeArr = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
				'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
				'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6',
				'7', '8', '9' };
		String codeStr = "";
		Random ran = new Random();
		for (int i = 0; i < length; i++) {
			int index = ran.nextInt(codeArr.length);
			codeStr += codeArr[index];
		}

		return codeStr;
	}

	/**
	 * 生成验证图片的方法
	 * @param code 验证码
	 * @return 图片输入流
	 */
	public InputStream createImage(String code) {
		// 创建图片
		BufferedImage image = new BufferedImage(180, 40, BufferedImage.TYPE_INT_RGB);
		// 画笔
		Graphics g = image.getGraphics();
		// 设置背景颜色
		g.setColor(Color.WHITE);
		// 画矩形
		g.fillRect(0, 0, 180, 40);
		Font font = new Font("黑体", Font.PLAIN, 30);
		Random ran = new Random();
		// 画字符串
		for (int i = 0; i < code.length(); i++) {
			g.setColor(Color.GRAY);
			g.drawLine(ran.nextInt(180), ran.nextInt(40), ran.nextInt(180), ran.nextInt(40));
			// 设置字体颜色
			int ranNum = ran.nextInt(4) + 1;
			if (ranNum == 1) {
				g.setColor(Color.RED);
			}
			if (ranNum == 2) {
				g.setColor(Color.GREEN);
			}
			if (ranNum == 3) {
				g.setColor(Color.BLACK);
			}
			if (ranNum == 4) {
				g.setColor(Color.BLUE);
			}
			// 设置字体样式
			g.setFont(font);
			String c = code.charAt(i) + "";
			g.drawString(c, 15 * i + 30, 30);

		}
		// 将image放置到inputStream
		ByteArrayOutputStream os = new ByteArrayOutputStream();

		try {
			// 将图片，写入到OS
			ImageIO.write(image, "jpg", os);
			ByteArrayInputStream is = new ByteArrayInputStream(os.toByteArray());
			return is;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}

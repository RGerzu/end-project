package org.test.service;

import javax.annotation.Resource;

import com.github.pagehelper.PageHelper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.test.dto.SearchStaffInfoDto;
import org.test.mapper.StaffInfoMapper;
import org.test.pojo.*;

import java.util.List;

@Service
@Transactional(rollbackFor=Exception.class) // 只要报错就回滚
public class StaffInfoServiceImpl implements StaffInfoService{

    @Resource
    private StaffInfoMapper staffInfoMapper;


    @Override
    public Integer insertStaffInfo(StaffInfo staff) {
        // TODO Auto-generated method stub
        return staffInfoMapper.insertStaffInfo(staff);
    }

    @Override
    public Integer updateStaffInfo(StaffInfo staffInfo) {
        // TODO Auto-generated method stub
        return staffInfoMapper.updateStaffInfo(staffInfo);
    }

    @Override
    public Integer deleteStaffInfoById(Long staffId) {
        // TODO Auto-generated method stub
        return staffInfoMapper.deleteStaffInfoById(staffId);
    }

    @Override
    public List<ProductNew> selectByPage(SearchStaffInfoDto dto) {
        // 判断参数
        // 分页
        PageHelper.offsetPage(dto.getOffset(), dto.getLimit());
        return staffInfoMapper.selectByPage(dto);
    }

    @Override
    public Long countStaffInfo(SearchStaffInfoDto dto) {
        // 判断参数
        return staffInfoMapper.countStaffInfo(dto);
    }

    @Override
    public ProductNew selectStaffInfoById(Long staffId) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoById(staffId);
    }

    @Override
    public List<StaffInfo> selectByAll() {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectByAll();
    }

    @Override
    public StaffInfo selectStaffInfoByUid(String staffNumber) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoByUid(staffNumber);
    }

    @Override
    public StaffInfo selectStaffInfoByNa(String staffAccount) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoByNa(staffAccount);
    }

    @Override
    public StaffInfo selectStaffInfoByPh(String staffPhone) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoByPh(staffPhone);
    }

    @Override
    public StaffInfo selectStaffInfoByUidAndPwd(String staffAccount, String staffPwd) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoByUidAndPwd(staffAccount, staffPwd);
    }

    @Override
    public StaffInfo selectStaffInfoByNaAndPh(String staffName, String staffPhone) {
        // TODO Auto-generated method stub
        return staffInfoMapper.selectStaffInfoByNaAndPh(staffName, staffPhone);
    }

    @Override
    public List<Statistics> selectStatistics() {

        return staffInfoMapper.selectStatistics();
    }

    @Override
    public List<StatisticsIsPay> selectOrderIspay() {
        return staffInfoMapper.selectOrderIspay();
    }

    @Override
    public List<OrderCount> selectCount() {
        return staffInfoMapper.selectCount();
    }
}